CREATE DATABASE crm;
\connect crm
CREATE TABLE accounts (c_custkey integer, account_manager varchar(40), tier varchar(10));
COPY accounts (c_custkey, account_manager, tier) FROM stdin;
1	Anna Weber	standard
2	Mei Lin	standard
3	Luca Rossi	standard
4	Priya Shah	standard
5	Tom Becker	standard
6	Diego Santos	key
7	Anna Weber	standard
8	Claire Martin	standard
9	Mei Lin	standard
10	Diego Santos	standard
11	Luca Rossi	standard
12	Diego Santos	standard
13	Priya Shah	standard
14	Tom Becker	standard
15	Priya Shah	standard
16	Sam Carter	standard
17	Diego Santos	standard
18	Tom Becker	standard
19	Priya Shah	standard
20	Diego Santos	standard
21	Tom Becker	standard
22	Sam Carter	key
23	Mei Lin	standard
24	Sam Carter	standard
25	Claire Martin	standard
26	Tom Becker	standard
27	Claire Martin	key
28	Diego Santos	standard
29	Anna Weber	standard
30	Priya Shah	standard
31	Sam Carter	standard
32	Anna Weber	standard
33	Diego Santos	standard
34	Anna Weber	standard
35	Priya Shah	standard
36	Luca Rossi	standard
37	Tom Becker	standard
38	Diego Santos	standard
39	Claire Martin	standard
40	Priya Shah	standard
41	Claire Martin	standard
42	Anna Weber	standard
43	Anna Weber	standard
44	Claire Martin	standard
45	Diego Santos	standard
46	Anna Weber	standard
47	Diego Santos	standard
48	Luca Rossi	standard
49	Mei Lin	standard
50	Claire Martin	standard
51	Anna Weber	standard
52	Tom Becker	key
53	Anna Weber	standard
54	Tom Becker	key
55	Luca Rossi	standard
56	Diego Santos	standard
57	Sam Carter	standard
58	Mei Lin	standard
59	Anna Weber	standard
60	Anna Weber	standard
61	Tom Becker	key
62	Mei Lin	key
63	Diego Santos	standard
64	Claire Martin	key
65	Luca Rossi	standard
66	Diego Santos	standard
67	Anna Weber	standard
68	Tom Becker	standard
69	Mei Lin	standard
70	Sam Carter	standard
71	Sam Carter	standard
72	Claire Martin	standard
73	Priya Shah	key
74	Diego Santos	standard
75	Diego Santos	standard
76	Claire Martin	standard
77	Sam Carter	standard
78	Luca Rossi	standard
79	Luca Rossi	standard
80	Claire Martin	standard
81	Luca Rossi	key
82	Claire Martin	standard
83	Mei Lin	standard
84	Mei Lin	standard
85	Tom Becker	standard
86	Diego Santos	standard
87	Priya Shah	standard
88	Priya Shah	standard
89	Luca Rossi	standard
90	Tom Becker	standard
91	Diego Santos	standard
92	Luca Rossi	standard
93	Anna Weber	standard
94	Diego Santos	standard
95	Sam Carter	standard
96	Diego Santos	standard
97	Luca Rossi	key
98	Tom Becker	standard
99	Luca Rossi	standard
100	Sam Carter	key
101	Anna Weber	standard
102	Anna Weber	standard
103	Luca Rossi	standard
104	Anna Weber	standard
105	Tom Becker	standard
106	Mei Lin	standard
107	Priya Shah	standard
108	Tom Becker	standard
109	Mei Lin	standard
110	Luca Rossi	standard
111	Diego Santos	standard
112	Luca Rossi	standard
113	Tom Becker	standard
114	Tom Becker	standard
115	Mei Lin	standard
116	Sam Carter	standard
117	Mei Lin	standard
118	Diego Santos	standard
119	Anna Weber	standard
120	Mei Lin	standard
121	Luca Rossi	standard
122	Priya Shah	standard
123	Sam Carter	standard
124	Tom Becker	standard
125	Diego Santos	standard
126	Sam Carter	standard
127	Luca Rossi	standard
128	Priya Shah	standard
129	Claire Martin	standard
130	Anna Weber	standard
131	Anna Weber	key
132	Claire Martin	standard
133	Priya Shah	standard
134	Luca Rossi	standard
135	Tom Becker	standard
136	Tom Becker	standard
137	Anna Weber	standard
138	Priya Shah	key
139	Tom Becker	standard
140	Tom Becker	standard
141	Diego Santos	key
142	Luca Rossi	standard
143	Priya Shah	standard
144	Diego Santos	standard
145	Luca Rossi	standard
146	Sam Carter	standard
147	Anna Weber	standard
148	Priya Shah	standard
149	Luca Rossi	standard
150	Tom Becker	standard
151	Mei Lin	standard
152	Claire Martin	standard
153	Luca Rossi	standard
154	Priya Shah	standard
155	Diego Santos	standard
156	Mei Lin	standard
157	Mei Lin	standard
158	Anna Weber	standard
159	Priya Shah	standard
160	Diego Santos	standard
161	Anna Weber	standard
162	Diego Santos	standard
163	Diego Santos	standard
164	Mei Lin	standard
165	Anna Weber	standard
166	Sam Carter	standard
167	Anna Weber	standard
168	Mei Lin	standard
169	Mei Lin	standard
170	Mei Lin	standard
171	Claire Martin	standard
172	Mei Lin	standard
173	Priya Shah	key
174	Claire Martin	standard
175	Anna Weber	standard
176	Tom Becker	standard
177	Tom Becker	standard
178	Tom Becker	standard
179	Tom Becker	standard
180	Claire Martin	standard
181	Mei Lin	standard
182	Tom Becker	standard
183	Luca Rossi	standard
184	Anna Weber	standard
185	Tom Becker	standard
186	Claire Martin	standard
187	Luca Rossi	standard
188	Claire Martin	standard
189	Luca Rossi	key
190	Tom Becker	standard
191	Mei Lin	key
192	Sam Carter	standard
193	Claire Martin	standard
194	Diego Santos	standard
195	Priya Shah	key
196	Anna Weber	standard
197	Priya Shah	standard
198	Priya Shah	standard
199	Mei Lin	standard
200	Anna Weber	key
201	Mei Lin	standard
202	Claire Martin	standard
203	Tom Becker	standard
204	Mei Lin	standard
205	Diego Santos	standard
206	Anna Weber	key
207	Claire Martin	standard
208	Priya Shah	standard
209	Priya Shah	standard
210	Priya Shah	standard
211	Diego Santos	standard
212	Diego Santos	standard
213	Priya Shah	standard
214	Sam Carter	standard
215	Priya Shah	key
216	Sam Carter	standard
217	Luca Rossi	standard
218	Claire Martin	standard
219	Sam Carter	key
220	Priya Shah	key
221	Tom Becker	standard
222	Mei Lin	standard
223	Diego Santos	standard
224	Luca Rossi	standard
225	Luca Rossi	standard
226	Anna Weber	standard
227	Sam Carter	key
228	Priya Shah	standard
229	Priya Shah	standard
230	Mei Lin	standard
231	Diego Santos	standard
232	Anna Weber	key
233	Diego Santos	standard
234	Luca Rossi	standard
235	Tom Becker	standard
236	Tom Becker	standard
237	Sam Carter	standard
238	Claire Martin	standard
239	Sam Carter	standard
240	Luca Rossi	standard
241	Sam Carter	standard
242	Anna Weber	standard
243	Mei Lin	standard
244	Anna Weber	standard
245	Luca Rossi	standard
246	Mei Lin	standard
247	Diego Santos	standard
248	Luca Rossi	standard
249	Mei Lin	standard
250	Luca Rossi	standard
251	Anna Weber	standard
252	Sam Carter	standard
253	Tom Becker	standard
254	Tom Becker	standard
255	Tom Becker	standard
256	Luca Rossi	standard
257	Priya Shah	standard
258	Mei Lin	standard
259	Tom Becker	standard
260	Anna Weber	standard
261	Luca Rossi	standard
262	Anna Weber	standard
263	Claire Martin	standard
264	Claire Martin	standard
265	Priya Shah	key
266	Tom Becker	standard
267	Priya Shah	standard
268	Mei Lin	standard
269	Tom Becker	standard
270	Tom Becker	standard
271	Priya Shah	key
272	Priya Shah	standard
273	Luca Rossi	standard
274	Diego Santos	standard
275	Diego Santos	standard
276	Mei Lin	key
277	Anna Weber	standard
278	Diego Santos	standard
279	Priya Shah	standard
280	Sam Carter	standard
281	Mei Lin	standard
282	Mei Lin	key
283	Diego Santos	standard
284	Luca Rossi	standard
285	Anna Weber	standard
286	Mei Lin	standard
287	Sam Carter	standard
288	Mei Lin	standard
289	Anna Weber	standard
290	Mei Lin	standard
291	Claire Martin	standard
292	Priya Shah	standard
293	Anna Weber	standard
294	Tom Becker	standard
295	Mei Lin	standard
296	Anna Weber	standard
297	Diego Santos	standard
298	Anna Weber	key
299	Tom Becker	standard
300	Luca Rossi	standard
301	Tom Becker	standard
302	Priya Shah	standard
303	Diego Santos	standard
304	Luca Rossi	standard
305	Tom Becker	key
306	Priya Shah	standard
307	Anna Weber	standard
308	Sam Carter	standard
309	Sam Carter	standard
310	Luca Rossi	key
311	Diego Santos	standard
312	Claire Martin	standard
313	Sam Carter	standard
314	Claire Martin	standard
315	Priya Shah	standard
316	Priya Shah	standard
317	Luca Rossi	standard
318	Anna Weber	standard
319	Tom Becker	standard
320	Sam Carter	standard
321	Priya Shah	standard
322	Sam Carter	standard
323	Mei Lin	standard
324	Sam Carter	standard
325	Mei Lin	key
326	Priya Shah	standard
327	Tom Becker	standard
328	Diego Santos	standard
329	Diego Santos	standard
330	Anna Weber	standard
331	Luca Rossi	standard
332	Claire Martin	standard
333	Luca Rossi	standard
334	Anna Weber	standard
335	Tom Becker	standard
336	Luca Rossi	standard
337	Mei Lin	standard
338	Priya Shah	standard
339	Diego Santos	standard
340	Sam Carter	standard
341	Claire Martin	standard
342	Tom Becker	key
343	Sam Carter	standard
344	Luca Rossi	standard
345	Diego Santos	standard
346	Mei Lin	standard
347	Diego Santos	standard
348	Priya Shah	key
349	Priya Shah	standard
350	Anna Weber	standard
351	Claire Martin	standard
352	Anna Weber	standard
353	Diego Santos	standard
354	Mei Lin	standard
355	Mei Lin	standard
356	Anna Weber	standard
357	Priya Shah	standard
358	Priya Shah	standard
359	Sam Carter	standard
360	Claire Martin	standard
361	Sam Carter	standard
362	Priya Shah	standard
363	Luca Rossi	standard
364	Diego Santos	standard
365	Tom Becker	standard
366	Tom Becker	standard
367	Sam Carter	standard
368	Tom Becker	key
369	Sam Carter	standard
370	Sam Carter	standard
371	Priya Shah	standard
372	Tom Becker	standard
373	Tom Becker	standard
374	Mei Lin	standard
375	Tom Becker	standard
376	Diego Santos	standard
377	Claire Martin	standard
378	Mei Lin	standard
379	Tom Becker	standard
380	Sam Carter	key
381	Priya Shah	standard
382	Sam Carter	standard
383	Sam Carter	standard
384	Priya Shah	standard
385	Luca Rossi	standard
386	Luca Rossi	standard
387	Mei Lin	standard
388	Luca Rossi	standard
389	Claire Martin	standard
390	Priya Shah	standard
391	Tom Becker	key
392	Anna Weber	standard
393	Claire Martin	standard
394	Tom Becker	standard
395	Tom Becker	standard
396	Diego Santos	key
397	Sam Carter	standard
398	Anna Weber	standard
399	Tom Becker	standard
400	Anna Weber	standard
401	Sam Carter	key
402	Claire Martin	standard
403	Sam Carter	standard
404	Mei Lin	standard
405	Luca Rossi	standard
406	Anna Weber	standard
407	Claire Martin	standard
408	Priya Shah	standard
409	Sam Carter	standard
410	Priya Shah	standard
411	Priya Shah	key
412	Priya Shah	standard
413	Mei Lin	key
414	Mei Lin	standard
415	Sam Carter	standard
416	Luca Rossi	key
417	Mei Lin	standard
418	Luca Rossi	standard
419	Luca Rossi	standard
420	Diego Santos	standard
421	Priya Shah	standard
422	Sam Carter	standard
423	Luca Rossi	standard
424	Diego Santos	standard
425	Anna Weber	standard
426	Luca Rossi	key
427	Luca Rossi	standard
428	Claire Martin	standard
429	Luca Rossi	standard
430	Claire Martin	key
431	Tom Becker	standard
432	Diego Santos	standard
433	Anna Weber	standard
434	Priya Shah	standard
435	Anna Weber	standard
436	Diego Santos	standard
437	Diego Santos	standard
438	Luca Rossi	standard
439	Anna Weber	standard
440	Sam Carter	standard
441	Tom Becker	standard
442	Mei Lin	standard
443	Tom Becker	standard
444	Priya Shah	standard
445	Priya Shah	standard
446	Priya Shah	standard
447	Claire Martin	standard
448	Anna Weber	key
449	Luca Rossi	standard
450	Luca Rossi	key
451	Diego Santos	key
452	Sam Carter	standard
453	Anna Weber	standard
454	Priya Shah	standard
455	Anna Weber	standard
456	Sam Carter	standard
457	Anna Weber	standard
458	Sam Carter	key
459	Claire Martin	standard
460	Tom Becker	standard
461	Tom Becker	standard
462	Diego Santos	standard
463	Tom Becker	standard
464	Luca Rossi	standard
465	Sam Carter	standard
466	Sam Carter	standard
467	Mei Lin	standard
468	Diego Santos	standard
469	Priya Shah	standard
470	Sam Carter	standard
471	Mei Lin	standard
472	Mei Lin	standard
473	Tom Becker	standard
474	Diego Santos	standard
475	Diego Santos	key
476	Anna Weber	standard
477	Mei Lin	standard
478	Anna Weber	standard
479	Claire Martin	key
480	Diego Santos	key
481	Sam Carter	standard
482	Luca Rossi	standard
483	Sam Carter	standard
484	Tom Becker	standard
485	Luca Rossi	standard
486	Tom Becker	standard
487	Priya Shah	standard
488	Tom Becker	standard
489	Priya Shah	standard
490	Diego Santos	standard
491	Diego Santos	standard
492	Anna Weber	standard
493	Diego Santos	standard
494	Luca Rossi	standard
495	Tom Becker	standard
496	Luca Rossi	standard
497	Mei Lin	standard
498	Diego Santos	standard
499	Diego Santos	key
500	Mei Lin	standard
501	Luca Rossi	standard
502	Priya Shah	standard
503	Priya Shah	standard
504	Claire Martin	standard
505	Sam Carter	standard
506	Tom Becker	standard
507	Mei Lin	standard
508	Sam Carter	standard
509	Anna Weber	standard
510	Mei Lin	standard
511	Anna Weber	standard
512	Tom Becker	standard
513	Claire Martin	standard
514	Mei Lin	standard
515	Claire Martin	standard
516	Priya Shah	standard
517	Priya Shah	standard
518	Tom Becker	standard
519	Luca Rossi	standard
520	Anna Weber	standard
521	Luca Rossi	standard
522	Mei Lin	standard
523	Diego Santos	standard
524	Sam Carter	standard
525	Mei Lin	standard
526	Tom Becker	standard
527	Diego Santos	standard
528	Diego Santos	standard
529	Claire Martin	standard
530	Mei Lin	standard
531	Diego Santos	standard
532	Mei Lin	standard
533	Priya Shah	standard
534	Priya Shah	standard
535	Diego Santos	standard
536	Priya Shah	standard
537	Mei Lin	standard
538	Priya Shah	standard
539	Sam Carter	standard
540	Diego Santos	key
541	Claire Martin	standard
542	Sam Carter	standard
543	Priya Shah	standard
544	Diego Santos	standard
545	Mei Lin	standard
546	Sam Carter	standard
547	Diego Santos	standard
548	Anna Weber	standard
549	Anna Weber	standard
550	Priya Shah	standard
551	Sam Carter	standard
552	Anna Weber	standard
553	Priya Shah	standard
554	Sam Carter	key
555	Anna Weber	key
556	Sam Carter	standard
557	Priya Shah	standard
558	Tom Becker	standard
559	Claire Martin	standard
560	Priya Shah	standard
561	Diego Santos	standard
562	Diego Santos	standard
563	Anna Weber	standard
564	Anna Weber	key
565	Luca Rossi	standard
566	Diego Santos	key
567	Anna Weber	standard
568	Luca Rossi	standard
569	Tom Becker	key
570	Anna Weber	key
571	Priya Shah	standard
572	Sam Carter	standard
573	Tom Becker	standard
574	Priya Shah	standard
575	Luca Rossi	standard
576	Diego Santos	standard
577	Sam Carter	standard
578	Luca Rossi	standard
579	Diego Santos	key
580	Tom Becker	standard
581	Diego Santos	standard
582	Priya Shah	standard
583	Luca Rossi	standard
584	Tom Becker	standard
585	Diego Santos	standard
586	Sam Carter	standard
587	Luca Rossi	standard
588	Luca Rossi	standard
589	Anna Weber	standard
590	Claire Martin	standard
591	Luca Rossi	standard
592	Anna Weber	key
593	Priya Shah	standard
594	Mei Lin	standard
595	Anna Weber	standard
596	Claire Martin	standard
597	Mei Lin	standard
598	Anna Weber	standard
599	Anna Weber	standard
600	Diego Santos	standard
601	Mei Lin	standard
602	Diego Santos	standard
603	Mei Lin	standard
604	Diego Santos	standard
605	Diego Santos	key
606	Luca Rossi	standard
607	Sam Carter	standard
608	Diego Santos	standard
609	Claire Martin	standard
610	Mei Lin	standard
611	Mei Lin	key
612	Anna Weber	standard
613	Claire Martin	standard
614	Diego Santos	standard
615	Tom Becker	standard
616	Luca Rossi	standard
617	Mei Lin	standard
618	Tom Becker	key
619	Claire Martin	standard
620	Mei Lin	standard
621	Priya Shah	standard
622	Priya Shah	key
623	Tom Becker	standard
624	Claire Martin	standard
625	Claire Martin	standard
626	Luca Rossi	standard
627	Tom Becker	standard
628	Diego Santos	standard
629	Sam Carter	standard
630	Priya Shah	standard
631	Tom Becker	standard
632	Anna Weber	standard
633	Anna Weber	standard
634	Sam Carter	standard
635	Luca Rossi	standard
636	Diego Santos	standard
637	Diego Santos	standard
638	Luca Rossi	standard
639	Luca Rossi	standard
640	Mei Lin	standard
641	Anna Weber	standard
642	Priya Shah	standard
643	Sam Carter	standard
644	Sam Carter	standard
645	Claire Martin	standard
646	Tom Becker	standard
647	Luca Rossi	key
648	Mei Lin	standard
649	Luca Rossi	standard
650	Diego Santos	standard
651	Claire Martin	standard
652	Priya Shah	key
653	Sam Carter	standard
654	Tom Becker	standard
655	Diego Santos	standard
656	Diego Santos	standard
657	Diego Santos	standard
658	Mei Lin	standard
659	Anna Weber	key
660	Diego Santos	standard
661	Anna Weber	standard
662	Anna Weber	standard
663	Priya Shah	standard
664	Tom Becker	standard
665	Luca Rossi	standard
666	Sam Carter	standard
667	Mei Lin	standard
668	Tom Becker	standard
669	Priya Shah	key
670	Tom Becker	standard
671	Claire Martin	standard
672	Diego Santos	standard
673	Luca Rossi	standard
674	Luca Rossi	standard
675	Priya Shah	standard
676	Tom Becker	standard
677	Sam Carter	standard
678	Priya Shah	standard
679	Sam Carter	standard
680	Mei Lin	key
681	Luca Rossi	standard
682	Mei Lin	key
683	Sam Carter	standard
684	Anna Weber	key
685	Priya Shah	standard
686	Diego Santos	standard
687	Claire Martin	standard
688	Priya Shah	standard
689	Sam Carter	standard
690	Mei Lin	standard
691	Tom Becker	standard
692	Anna Weber	standard
693	Luca Rossi	standard
694	Anna Weber	standard
695	Sam Carter	standard
696	Tom Becker	standard
697	Claire Martin	standard
698	Sam Carter	standard
699	Sam Carter	standard
700	Claire Martin	standard
701	Anna Weber	standard
702	Tom Becker	standard
703	Mei Lin	standard
704	Mei Lin	standard
705	Luca Rossi	standard
706	Claire Martin	standard
707	Diego Santos	standard
708	Luca Rossi	standard
709	Claire Martin	standard
710	Priya Shah	key
711	Tom Becker	standard
712	Tom Becker	standard
713	Priya Shah	standard
714	Tom Becker	standard
715	Tom Becker	standard
716	Sam Carter	key
717	Sam Carter	standard
718	Luca Rossi	standard
719	Luca Rossi	standard
720	Tom Becker	standard
721	Mei Lin	standard
722	Anna Weber	key
723	Anna Weber	standard
724	Sam Carter	standard
725	Priya Shah	standard
726	Diego Santos	standard
727	Anna Weber	standard
728	Anna Weber	standard
729	Tom Becker	standard
730	Diego Santos	standard
731	Claire Martin	standard
732	Tom Becker	standard
733	Anna Weber	standard
734	Mei Lin	standard
735	Diego Santos	standard
736	Priya Shah	standard
737	Luca Rossi	standard
738	Mei Lin	standard
739	Mei Lin	standard
740	Priya Shah	key
741	Mei Lin	standard
742	Priya Shah	standard
743	Claire Martin	standard
744	Diego Santos	standard
745	Claire Martin	standard
746	Anna Weber	key
747	Claire Martin	key
748	Mei Lin	standard
749	Tom Becker	standard
750	Mei Lin	standard
751	Claire Martin	standard
752	Sam Carter	standard
753	Luca Rossi	key
754	Diego Santos	key
755	Diego Santos	standard
756	Claire Martin	standard
757	Luca Rossi	standard
758	Priya Shah	standard
759	Sam Carter	standard
760	Diego Santos	standard
761	Priya Shah	standard
762	Priya Shah	standard
763	Diego Santos	key
764	Tom Becker	key
765	Sam Carter	standard
766	Mei Lin	standard
767	Luca Rossi	standard
768	Mei Lin	standard
769	Tom Becker	standard
770	Anna Weber	standard
771	Claire Martin	standard
772	Claire Martin	standard
773	Anna Weber	standard
774	Diego Santos	standard
775	Mei Lin	standard
776	Sam Carter	standard
777	Claire Martin	standard
778	Luca Rossi	standard
779	Priya Shah	standard
780	Tom Becker	standard
781	Mei Lin	standard
782	Priya Shah	standard
783	Diego Santos	key
784	Anna Weber	standard
785	Anna Weber	standard
786	Anna Weber	key
787	Sam Carter	key
788	Claire Martin	standard
789	Tom Becker	key
790	Priya Shah	standard
791	Mei Lin	standard
792	Diego Santos	standard
793	Sam Carter	standard
794	Sam Carter	standard
795	Tom Becker	standard
796	Anna Weber	standard
797	Sam Carter	standard
798	Diego Santos	standard
799	Claire Martin	standard
800	Anna Weber	standard
801	Diego Santos	standard
802	Diego Santos	key
803	Claire Martin	standard
804	Sam Carter	standard
805	Luca Rossi	standard
806	Priya Shah	standard
807	Claire Martin	standard
808	Diego Santos	standard
809	Diego Santos	standard
810	Mei Lin	standard
811	Mei Lin	standard
812	Sam Carter	standard
813	Tom Becker	standard
814	Mei Lin	standard
815	Anna Weber	standard
816	Anna Weber	standard
817	Anna Weber	standard
818	Mei Lin	standard
819	Tom Becker	standard
820	Luca Rossi	key
821	Anna Weber	key
822	Diego Santos	standard
823	Mei Lin	key
824	Diego Santos	standard
825	Claire Martin	standard
826	Mei Lin	standard
827	Priya Shah	standard
828	Anna Weber	standard
829	Anna Weber	standard
830	Diego Santos	key
831	Diego Santos	standard
832	Anna Weber	key
833	Mei Lin	standard
834	Mei Lin	standard
835	Luca Rossi	standard
836	Anna Weber	standard
837	Claire Martin	standard
838	Mei Lin	standard
839	Luca Rossi	standard
840	Sam Carter	standard
841	Claire Martin	standard
842	Luca Rossi	standard
843	Luca Rossi	key
844	Claire Martin	standard
845	Mei Lin	standard
846	Anna Weber	standard
847	Sam Carter	key
848	Tom Becker	standard
849	Priya Shah	standard
850	Claire Martin	standard
851	Tom Becker	standard
852	Diego Santos	standard
853	Mei Lin	standard
854	Luca Rossi	standard
855	Diego Santos	standard
856	Sam Carter	standard
857	Luca Rossi	standard
858	Anna Weber	standard
859	Luca Rossi	standard
860	Diego Santos	standard
861	Anna Weber	standard
862	Tom Becker	standard
863	Anna Weber	standard
864	Priya Shah	key
865	Claire Martin	standard
866	Mei Lin	standard
867	Luca Rossi	standard
868	Tom Becker	key
869	Claire Martin	key
870	Sam Carter	standard
871	Anna Weber	standard
872	Luca Rossi	standard
873	Sam Carter	standard
874	Priya Shah	standard
875	Sam Carter	key
876	Mei Lin	standard
877	Anna Weber	standard
878	Luca Rossi	standard
879	Sam Carter	standard
880	Claire Martin	standard
881	Luca Rossi	key
882	Anna Weber	standard
883	Claire Martin	standard
884	Claire Martin	standard
885	Priya Shah	standard
886	Anna Weber	key
887	Priya Shah	key
888	Luca Rossi	standard
889	Mei Lin	key
890	Priya Shah	key
891	Priya Shah	standard
892	Diego Santos	standard
893	Sam Carter	standard
894	Tom Becker	standard
895	Diego Santos	standard
896	Priya Shah	standard
897	Claire Martin	standard
898	Sam Carter	standard
899	Priya Shah	standard
900	Priya Shah	standard
901	Anna Weber	standard
902	Claire Martin	standard
903	Claire Martin	key
904	Priya Shah	standard
905	Priya Shah	standard
906	Priya Shah	standard
907	Anna Weber	standard
908	Diego Santos	standard
909	Tom Becker	key
910	Anna Weber	standard
911	Sam Carter	standard
912	Diego Santos	standard
913	Priya Shah	standard
914	Luca Rossi	standard
915	Claire Martin	standard
916	Anna Weber	standard
917	Sam Carter	standard
918	Claire Martin	standard
919	Diego Santos	standard
920	Sam Carter	standard
921	Sam Carter	standard
922	Priya Shah	standard
923	Luca Rossi	standard
924	Sam Carter	standard
925	Claire Martin	standard
926	Priya Shah	standard
927	Mei Lin	standard
928	Anna Weber	key
929	Priya Shah	standard
930	Priya Shah	standard
931	Mei Lin	standard
932	Anna Weber	key
933	Anna Weber	standard
934	Anna Weber	key
935	Luca Rossi	standard
936	Sam Carter	standard
937	Tom Becker	key
938	Diego Santos	standard
939	Priya Shah	standard
940	Claire Martin	standard
941	Tom Becker	key
942	Tom Becker	standard
943	Luca Rossi	standard
944	Luca Rossi	standard
945	Priya Shah	standard
946	Mei Lin	standard
947	Priya Shah	standard
948	Tom Becker	key
949	Diego Santos	standard
950	Sam Carter	standard
951	Luca Rossi	standard
952	Anna Weber	standard
953	Claire Martin	standard
954	Sam Carter	standard
955	Sam Carter	key
956	Sam Carter	standard
957	Sam Carter	standard
958	Claire Martin	standard
959	Claire Martin	standard
960	Diego Santos	standard
961	Priya Shah	standard
962	Luca Rossi	standard
963	Claire Martin	standard
964	Mei Lin	standard
965	Priya Shah	standard
966	Diego Santos	standard
967	Anna Weber	standard
968	Priya Shah	standard
969	Tom Becker	standard
970	Tom Becker	key
971	Claire Martin	standard
972	Anna Weber	key
973	Tom Becker	standard
974	Anna Weber	standard
975	Mei Lin	standard
976	Priya Shah	standard
977	Diego Santos	standard
978	Mei Lin	standard
979	Luca Rossi	standard
980	Tom Becker	standard
981	Anna Weber	standard
982	Diego Santos	standard
983	Luca Rossi	standard
984	Claire Martin	key
985	Mei Lin	standard
986	Mei Lin	standard
987	Anna Weber	standard
988	Mei Lin	standard
989	Sam Carter	standard
990	Priya Shah	standard
991	Claire Martin	standard
992	Claire Martin	standard
993	Anna Weber	key
994	Anna Weber	standard
995	Claire Martin	standard
996	Sam Carter	standard
997	Luca Rossi	standard
998	Claire Martin	key
999	Luca Rossi	standard
1000	Mei Lin	standard
1001	Diego Santos	standard
1002	Diego Santos	standard
1003	Anna Weber	standard
1004	Tom Becker	standard
1005	Claire Martin	key
1006	Luca Rossi	standard
1007	Anna Weber	standard
1008	Claire Martin	standard
1009	Tom Becker	standard
1010	Claire Martin	standard
1011	Mei Lin	standard
1012	Anna Weber	standard
1013	Luca Rossi	standard
1014	Mei Lin	standard
1015	Diego Santos	standard
1016	Luca Rossi	standard
1017	Diego Santos	standard
1018	Priya Shah	standard
1019	Mei Lin	key
1020	Claire Martin	standard
1021	Diego Santos	standard
1022	Tom Becker	standard
1023	Mei Lin	standard
1024	Tom Becker	standard
1025	Tom Becker	standard
1026	Luca Rossi	standard
1027	Sam Carter	standard
1028	Diego Santos	standard
1029	Anna Weber	standard
1030	Luca Rossi	standard
1031	Sam Carter	standard
1032	Luca Rossi	standard
1033	Priya Shah	standard
1034	Diego Santos	standard
1035	Priya Shah	standard
1036	Luca Rossi	standard
1037	Anna Weber	standard
1038	Anna Weber	standard
1039	Tom Becker	key
1040	Diego Santos	standard
1041	Mei Lin	standard
1042	Priya Shah	standard
1043	Anna Weber	standard
1044	Anna Weber	standard
1045	Claire Martin	key
1046	Tom Becker	standard
1047	Claire Martin	standard
1048	Mei Lin	standard
1049	Anna Weber	standard
1050	Tom Becker	standard
1051	Anna Weber	standard
1052	Tom Becker	standard
1053	Diego Santos	standard
1054	Mei Lin	standard
1055	Sam Carter	key
1056	Claire Martin	standard
1057	Tom Becker	standard
1058	Sam Carter	standard
1059	Mei Lin	standard
1060	Priya Shah	standard
1061	Tom Becker	standard
1062	Tom Becker	standard
1063	Mei Lin	standard
1064	Luca Rossi	standard
1065	Luca Rossi	standard
1066	Mei Lin	standard
1067	Luca Rossi	standard
1068	Priya Shah	standard
1069	Anna Weber	standard
1070	Luca Rossi	key
1071	Luca Rossi	standard
1072	Diego Santos	standard
1073	Tom Becker	standard
1074	Claire Martin	key
1075	Tom Becker	standard
1076	Sam Carter	standard
1077	Tom Becker	standard
1078	Tom Becker	key
1079	Sam Carter	standard
1080	Claire Martin	standard
1081	Priya Shah	standard
1082	Priya Shah	standard
1083	Diego Santos	standard
1084	Sam Carter	key
1085	Mei Lin	standard
1086	Sam Carter	standard
1087	Claire Martin	standard
1088	Diego Santos	standard
1089	Luca Rossi	standard
1090	Claire Martin	standard
1091	Tom Becker	key
1092	Luca Rossi	standard
1093	Mei Lin	key
1094	Tom Becker	standard
1095	Sam Carter	standard
1096	Anna Weber	standard
1097	Anna Weber	standard
1098	Diego Santos	standard
1099	Priya Shah	standard
1100	Diego Santos	standard
1101	Tom Becker	standard
1102	Anna Weber	key
1103	Diego Santos	standard
1104	Tom Becker	standard
1105	Priya Shah	standard
1106	Mei Lin	standard
1107	Sam Carter	standard
1108	Mei Lin	standard
1109	Tom Becker	standard
1110	Sam Carter	standard
1111	Tom Becker	standard
1112	Luca Rossi	standard
1113	Luca Rossi	standard
1114	Luca Rossi	standard
1115	Tom Becker	standard
1116	Claire Martin	standard
1117	Sam Carter	key
1118	Anna Weber	standard
1119	Claire Martin	key
1120	Anna Weber	standard
1121	Diego Santos	standard
1122	Diego Santos	standard
1123	Luca Rossi	standard
1124	Mei Lin	standard
1125	Claire Martin	standard
1126	Luca Rossi	standard
1127	Tom Becker	standard
1128	Diego Santos	standard
1129	Claire Martin	standard
1130	Claire Martin	standard
1131	Mei Lin	standard
1132	Anna Weber	standard
1133	Claire Martin	standard
1134	Claire Martin	standard
1135	Diego Santos	standard
1136	Mei Lin	standard
1137	Luca Rossi	standard
1138	Mei Lin	standard
1139	Sam Carter	standard
1140	Luca Rossi	standard
1141	Tom Becker	standard
1142	Priya Shah	standard
1143	Mei Lin	standard
1144	Diego Santos	key
1145	Anna Weber	standard
1146	Mei Lin	standard
1147	Sam Carter	standard
1148	Sam Carter	standard
1149	Luca Rossi	standard
1150	Sam Carter	standard
1151	Sam Carter	standard
1152	Tom Becker	standard
1153	Mei Lin	standard
1154	Diego Santos	key
1155	Tom Becker	standard
1156	Priya Shah	standard
1157	Sam Carter	standard
1158	Claire Martin	standard
1159	Mei Lin	standard
1160	Priya Shah	standard
1161	Mei Lin	standard
1162	Sam Carter	standard
1163	Tom Becker	key
1164	Sam Carter	standard
1165	Anna Weber	standard
1166	Sam Carter	standard
1167	Diego Santos	key
1168	Priya Shah	standard
1169	Tom Becker	standard
1170	Sam Carter	key
1171	Claire Martin	standard
1172	Priya Shah	standard
1173	Luca Rossi	standard
1174	Claire Martin	standard
1175	Sam Carter	standard
1176	Tom Becker	standard
1177	Luca Rossi	standard
1178	Anna Weber	standard
1179	Mei Lin	standard
1180	Tom Becker	standard
1181	Diego Santos	standard
1182	Anna Weber	key
1183	Luca Rossi	standard
1184	Diego Santos	standard
1185	Tom Becker	standard
1186	Claire Martin	standard
1187	Diego Santos	standard
1188	Anna Weber	standard
1189	Claire Martin	standard
1190	Tom Becker	key
1191	Anna Weber	standard
1192	Claire Martin	standard
1193	Priya Shah	standard
1194	Claire Martin	standard
1195	Claire Martin	standard
1196	Claire Martin	standard
1197	Anna Weber	standard
1198	Luca Rossi	standard
1199	Luca Rossi	standard
1200	Mei Lin	standard
1201	Mei Lin	standard
1202	Mei Lin	standard
1203	Luca Rossi	standard
1204	Luca Rossi	standard
1205	Tom Becker	standard
1206	Luca Rossi	standard
1207	Diego Santos	key
1208	Luca Rossi	standard
1209	Diego Santos	standard
1210	Mei Lin	standard
1211	Anna Weber	standard
1212	Anna Weber	key
1213	Claire Martin	key
1214	Sam Carter	key
1215	Tom Becker	standard
1216	Priya Shah	standard
1217	Diego Santos	standard
1218	Priya Shah	standard
1219	Tom Becker	standard
1220	Mei Lin	standard
1221	Diego Santos	standard
1222	Diego Santos	standard
1223	Sam Carter	standard
1224	Tom Becker	key
1225	Luca Rossi	standard
1226	Tom Becker	standard
1227	Claire Martin	standard
1228	Diego Santos	key
1229	Anna Weber	standard
1230	Claire Martin	standard
1231	Tom Becker	standard
1232	Priya Shah	standard
1233	Anna Weber	standard
1234	Claire Martin	standard
1235	Claire Martin	standard
1236	Tom Becker	standard
1237	Priya Shah	standard
1238	Anna Weber	standard
1239	Sam Carter	standard
1240	Claire Martin	standard
1241	Priya Shah	standard
1242	Priya Shah	standard
1243	Tom Becker	standard
1244	Tom Becker	standard
1245	Priya Shah	standard
1246	Anna Weber	standard
1247	Priya Shah	standard
1248	Mei Lin	standard
1249	Mei Lin	standard
1250	Tom Becker	standard
1251	Luca Rossi	standard
1252	Priya Shah	standard
1253	Diego Santos	key
1254	Luca Rossi	standard
1255	Tom Becker	key
1256	Luca Rossi	standard
1257	Sam Carter	standard
1258	Claire Martin	standard
1259	Claire Martin	standard
1260	Sam Carter	standard
1261	Mei Lin	standard
1262	Anna Weber	standard
1263	Tom Becker	standard
1264	Luca Rossi	standard
1265	Tom Becker	standard
1266	Claire Martin	standard
1267	Sam Carter	standard
1268	Priya Shah	standard
1269	Luca Rossi	standard
1270	Anna Weber	standard
1271	Sam Carter	standard
1272	Claire Martin	standard
1273	Anna Weber	standard
1274	Claire Martin	standard
1275	Priya Shah	standard
1276	Sam Carter	standard
1277	Diego Santos	standard
1278	Mei Lin	standard
1279	Mei Lin	key
1280	Priya Shah	key
1281	Sam Carter	standard
1282	Sam Carter	standard
1283	Claire Martin	standard
1284	Anna Weber	standard
1285	Anna Weber	key
1286	Luca Rossi	standard
1287	Sam Carter	standard
1288	Priya Shah	standard
1289	Diego Santos	standard
1290	Claire Martin	standard
1291	Mei Lin	standard
1292	Diego Santos	standard
1293	Diego Santos	standard
1294	Luca Rossi	standard
1295	Tom Becker	standard
1296	Luca Rossi	standard
1297	Luca Rossi	standard
1298	Sam Carter	standard
1299	Sam Carter	standard
1300	Tom Becker	standard
1301	Anna Weber	standard
1302	Luca Rossi	standard
1303	Sam Carter	standard
1304	Sam Carter	standard
1305	Priya Shah	key
1306	Claire Martin	standard
1307	Tom Becker	standard
1308	Tom Becker	key
1309	Mei Lin	standard
1310	Diego Santos	key
1311	Priya Shah	standard
1312	Tom Becker	standard
1313	Anna Weber	standard
1314	Tom Becker	standard
1315	Sam Carter	key
1316	Sam Carter	standard
1317	Mei Lin	key
1318	Diego Santos	standard
1319	Claire Martin	standard
1320	Claire Martin	standard
1321	Tom Becker	standard
1322	Priya Shah	standard
1323	Priya Shah	standard
1324	Anna Weber	standard
1325	Mei Lin	standard
1326	Sam Carter	standard
1327	Priya Shah	standard
1328	Diego Santos	standard
1329	Diego Santos	key
1330	Luca Rossi	standard
1331	Anna Weber	standard
1332	Mei Lin	standard
1333	Priya Shah	standard
1334	Mei Lin	standard
1335	Sam Carter	standard
1336	Priya Shah	standard
1337	Diego Santos	standard
1338	Luca Rossi	standard
1339	Priya Shah	standard
1340	Sam Carter	key
1341	Tom Becker	standard
1342	Claire Martin	standard
1343	Priya Shah	standard
1344	Priya Shah	standard
1345	Claire Martin	standard
1346	Tom Becker	standard
1347	Sam Carter	key
1348	Tom Becker	standard
1349	Priya Shah	standard
1350	Priya Shah	key
1351	Claire Martin	standard
1352	Anna Weber	key
1353	Tom Becker	standard
1354	Luca Rossi	standard
1355	Sam Carter	standard
1356	Claire Martin	standard
1357	Priya Shah	standard
1358	Tom Becker	standard
1359	Anna Weber	standard
1360	Mei Lin	standard
1361	Sam Carter	key
1362	Luca Rossi	key
1363	Sam Carter	standard
1364	Tom Becker	standard
1365	Priya Shah	standard
1366	Anna Weber	standard
1367	Claire Martin	key
1368	Diego Santos	standard
1369	Priya Shah	standard
1370	Diego Santos	standard
1371	Diego Santos	standard
1372	Diego Santos	standard
1373	Priya Shah	key
1374	Claire Martin	standard
1375	Mei Lin	key
1376	Diego Santos	standard
1377	Sam Carter	standard
1378	Priya Shah	standard
1379	Tom Becker	standard
1380	Diego Santos	standard
1381	Claire Martin	standard
1382	Claire Martin	standard
1383	Diego Santos	standard
1384	Diego Santos	standard
1385	Priya Shah	standard
1386	Luca Rossi	standard
1387	Tom Becker	standard
1388	Mei Lin	standard
1389	Luca Rossi	standard
1390	Sam Carter	standard
1391	Priya Shah	standard
1392	Sam Carter	key
1393	Diego Santos	standard
1394	Claire Martin	standard
1395	Tom Becker	standard
1396	Claire Martin	standard
1397	Diego Santos	key
1398	Claire Martin	standard
1399	Luca Rossi	key
1400	Priya Shah	standard
1401	Priya Shah	standard
1402	Sam Carter	standard
1403	Anna Weber	standard
1404	Priya Shah	standard
1405	Luca Rossi	key
1406	Anna Weber	standard
1407	Claire Martin	standard
1408	Diego Santos	standard
1409	Sam Carter	standard
1410	Luca Rossi	standard
1411	Anna Weber	standard
1412	Mei Lin	standard
1413	Priya Shah	standard
1414	Luca Rossi	standard
1415	Diego Santos	key
1416	Tom Becker	key
1417	Sam Carter	standard
1418	Luca Rossi	key
1419	Priya Shah	standard
1420	Tom Becker	standard
1421	Mei Lin	standard
1422	Diego Santos	standard
1423	Mei Lin	key
1424	Mei Lin	standard
1425	Tom Becker	standard
1426	Tom Becker	standard
1427	Mei Lin	standard
1428	Sam Carter	key
1429	Luca Rossi	standard
1430	Priya Shah	standard
1431	Mei Lin	standard
1432	Anna Weber	standard
1433	Priya Shah	standard
1434	Diego Santos	standard
1435	Anna Weber	standard
1436	Anna Weber	standard
1437	Diego Santos	standard
1438	Claire Martin	standard
1439	Mei Lin	key
1440	Mei Lin	standard
1441	Anna Weber	standard
1442	Sam Carter	standard
1443	Priya Shah	standard
1444	Diego Santos	standard
1445	Tom Becker	standard
1446	Mei Lin	standard
1447	Luca Rossi	standard
1448	Mei Lin	standard
1449	Sam Carter	standard
1450	Diego Santos	standard
1451	Diego Santos	standard
1452	Anna Weber	standard
1453	Anna Weber	standard
1454	Tom Becker	standard
1455	Luca Rossi	standard
1456	Luca Rossi	standard
1457	Priya Shah	standard
1458	Luca Rossi	standard
1459	Diego Santos	standard
1460	Mei Lin	standard
1461	Tom Becker	standard
1462	Anna Weber	standard
1463	Anna Weber	standard
1464	Luca Rossi	standard
1465	Priya Shah	standard
1466	Sam Carter	standard
1467	Diego Santos	standard
1468	Priya Shah	standard
1469	Mei Lin	key
1470	Anna Weber	standard
1471	Mei Lin	standard
1472	Tom Becker	standard
1473	Sam Carter	standard
1474	Tom Becker	key
1475	Luca Rossi	standard
1476	Claire Martin	standard
1477	Mei Lin	standard
1478	Diego Santos	standard
1479	Tom Becker	standard
1480	Priya Shah	standard
1481	Sam Carter	standard
1482	Diego Santos	standard
1483	Claire Martin	standard
1484	Sam Carter	standard
1485	Mei Lin	standard
1486	Tom Becker	standard
1487	Claire Martin	standard
1488	Tom Becker	standard
1489	Sam Carter	key
1490	Anna Weber	standard
1491	Diego Santos	key
1492	Priya Shah	standard
1493	Priya Shah	standard
1494	Anna Weber	standard
1495	Tom Becker	standard
1496	Tom Becker	standard
1497	Diego Santos	standard
1498	Diego Santos	standard
1499	Tom Becker	standard
1500	Tom Becker	standard
1501	Anna Weber	key
1502	Anna Weber	key
1503	Anna Weber	key
1504	Sam Carter	key
1505	Sam Carter	key
\.
CREATE TABLE account_events (event_id integer, c_custkey integer, event_date date, event_type varchar(20), summary varchar(200), account_manager varchar(40));
COPY account_events (event_id, c_custkey, event_date, event_type, summary, account_manager) FROM stdin;
1	616	1995-01-01	complaint	Invoice dispute, resolved.	Luca Rossi
2	625	1995-01-02	meeting	Site visit with purchasing.	Claire Martin
3	382	1995-01-04	support	Requested updated price list.	Sam Carter
4	1093	1995-01-07	meeting	Quarterly business review.	Mei Lin
5	512	1995-01-07	complaint	Late delivery on two order lines.	Tom Becker
6	1232	1995-01-09	support	Requested updated price list.	Priya Shah
7	407	1995-01-09	complaint	Late delivery on two order lines.	Claire Martin
8	463	1995-01-10	meeting	Quarterly business review.	Tom Becker
9	591	1995-01-10	meeting	Site visit with purchasing.	Luca Rossi
10	706	1995-01-10	complaint	Invoice dispute, resolved.	Claire Martin
11	1262	1995-01-13	support	Requested updated price list.	Anna Weber
12	1210	1995-01-14	complaint	Invoice dispute, resolved.	Mei Lin
13	1427	1995-01-16	support	Requested updated price list.	Mei Lin
14	644	1995-01-17	support	Requested updated price list.	Sam Carter
15	1086	1995-01-18	support	Requested updated price list.	Sam Carter
16	604	1995-01-19	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
17	932	1995-01-21	complaint	Late delivery on two order lines.	Anna Weber
18	1476	1995-01-21	meeting	Quarterly business review.	Claire Martin
19	1312	1995-01-22	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
20	51	1995-01-25	meeting	Quarterly business review.	Anna Weber
21	275	1995-01-26	complaint	Invoice dispute, resolved.	Diego Santos
22	548	1995-01-28	support	Requested updated price list.	Anna Weber
23	893	1995-01-29	meeting	Quarterly business review.	Sam Carter
24	1178	1995-01-29	meeting	Site visit with purchasing.	Anna Weber
25	1425	1995-01-31	support	Requested updated price list.	Tom Becker
26	1204	1995-02-01	meeting	Site visit with purchasing.	Luca Rossi
27	308	1995-02-01	meeting	Quarterly business review.	Sam Carter
28	1071	1995-02-01	meeting	Quarterly business review.	Luca Rossi
29	1065	1995-02-04	support	Requested updated price list.	Luca Rossi
30	428	1995-02-04	complaint	Invoice dispute, resolved.	Claire Martin
31	607	1995-02-05	support	Requested updated price list.	Sam Carter
32	1444	1995-02-06	complaint	Invoice dispute, resolved.	Diego Santos
33	516	1995-02-08	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
34	1329	1995-02-09	meeting	Site visit with purchasing.	Diego Santos
35	1085	1995-02-10	meeting	Site visit with purchasing.	Mei Lin
36	1500	1995-02-11	complaint	Invoice dispute, resolved.	Tom Becker
37	607	1995-02-11	meeting	Site visit with purchasing.	Sam Carter
38	1378	1995-02-13	complaint	Late delivery on two order lines.	Priya Shah
39	171	1995-02-13	complaint	Late delivery on two order lines.	Claire Martin
40	450	1995-02-13	complaint	Invoice dispute, resolved.	Luca Rossi
41	588	1995-02-13	meeting	Site visit with purchasing.	Luca Rossi
42	757	1995-02-14	complaint	Invoice dispute, resolved.	Luca Rossi
43	1079	1995-02-14	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
44	298	1995-02-15	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
45	1401	1995-02-15	complaint	Late delivery on two order lines.	Priya Shah
46	240	1995-02-16	meeting	Site visit with purchasing.	Luca Rossi
47	874	1995-02-16	meeting	Site visit with purchasing.	Priya Shah
48	1499	1995-02-18	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
49	889	1995-02-18	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
50	377	1995-02-19	complaint	Invoice dispute, resolved.	Claire Martin
51	959	1995-02-20	support	Requested updated price list.	Claire Martin
52	625	1995-02-20	meeting	Quarterly business review.	Claire Martin
53	577	1995-02-22	complaint	Late delivery on two order lines.	Sam Carter
54	1363	1995-02-25	support	Requested updated price list.	Sam Carter
55	1455	1995-02-26	meeting	Site visit with purchasing.	Luca Rossi
56	1494	1995-02-28	complaint	Invoice dispute, resolved.	Anna Weber
57	471	1995-03-01	complaint	Late delivery on two order lines.	Mei Lin
58	777	1995-03-02	support	Requested updated price list.	Claire Martin
59	681	1995-03-03	meeting	Site visit with purchasing.	Luca Rossi
60	916	1995-03-04	meeting	Quarterly business review.	Anna Weber
61	896	1995-03-05	complaint	Late delivery on two order lines.	Priya Shah
62	513	1995-03-05	complaint	Late delivery on two order lines.	Claire Martin
63	419	1995-03-06	meeting	Quarterly business review.	Luca Rossi
64	823	1995-03-07	complaint	Invoice dispute, resolved.	Mei Lin
65	1101	1995-03-08	meeting	Quarterly business review.	Tom Becker
66	1041	1995-03-10	support	Requested updated price list.	Mei Lin
67	194	1995-03-14	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
68	1246	1995-03-14	meeting	Quarterly business review.	Anna Weber
69	384	1995-03-16	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
70	86	1995-03-16	support	Requested updated price list.	Diego Santos
71	1060	1995-03-18	meeting	Quarterly business review.	Priya Shah
72	1160	1995-03-18	support	Requested updated price list.	Priya Shah
73	783	1995-03-21	complaint	Late delivery on two order lines.	Diego Santos
74	1484	1995-03-24	meeting	Quarterly business review.	Sam Carter
75	503	1995-03-25	meeting	Site visit with purchasing.	Priya Shah
76	225	1995-03-30	meeting	Site visit with purchasing.	Luca Rossi
77	1089	1995-04-02	complaint	Late delivery on two order lines.	Luca Rossi
78	811	1995-04-02	support	Requested updated price list.	Mei Lin
79	287	1995-04-03	meeting	Quarterly business review.	Sam Carter
80	1053	1995-04-04	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
81	350	1995-04-08	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
82	319	1995-04-10	complaint	Invoice dispute, resolved.	Tom Becker
83	828	1995-04-12	meeting	Quarterly business review.	Anna Weber
84	272	1995-04-12	meeting	Quarterly business review.	Priya Shah
85	1065	1995-04-15	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
86	572	1995-04-15	complaint	Late delivery on two order lines.	Sam Carter
87	932	1995-04-15	meeting	Quarterly business review.	Anna Weber
88	936	1995-04-18	complaint	Invoice dispute, resolved.	Sam Carter
89	179	1995-04-18	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
90	1065	1995-04-19	support	Requested updated price list.	Luca Rossi
91	1	1995-04-19	support	Requested updated price list.	Anna Weber
92	3	1995-04-20	complaint	Invoice dispute, resolved.	Luca Rossi
93	1349	1995-04-20	meeting	Site visit with purchasing.	Priya Shah
94	697	1995-04-20	complaint	Late delivery on two order lines.	Claire Martin
95	975	1995-04-23	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
96	1346	1995-04-23	complaint	Late delivery on two order lines.	Tom Becker
97	1387	1995-04-24	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
98	613	1995-04-25	complaint	Late delivery on two order lines.	Claire Martin
99	499	1995-04-25	complaint	Invoice dispute, resolved.	Diego Santos
100	22	1995-04-27	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
101	1332	1995-04-29	meeting	Quarterly business review.	Mei Lin
102	116	1995-05-02	meeting	Site visit with purchasing.	Sam Carter
103	266	1995-05-02	meeting	Quarterly business review.	Tom Becker
104	942	1995-05-02	meeting	Quarterly business review.	Tom Becker
105	418	1995-05-03	meeting	Site visit with purchasing.	Luca Rossi
106	783	1995-05-03	meeting	Site visit with purchasing.	Diego Santos
107	870	1995-05-04	support	Requested updated price list.	Sam Carter
108	850	1995-05-05	complaint	Invoice dispute, resolved.	Claire Martin
109	118	1995-05-09	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
110	20	1995-05-09	complaint	Invoice dispute, resolved.	Diego Santos
111	1334	1995-05-11	meeting	Site visit with purchasing.	Mei Lin
112	452	1995-05-13	meeting	Site visit with purchasing.	Sam Carter
113	684	1995-05-17	complaint	Invoice dispute, resolved.	Anna Weber
114	100	1995-05-18	support	Requested updated price list.	Sam Carter
115	913	1995-05-19	meeting	Quarterly business review.	Priya Shah
116	1079	1995-05-21	meeting	Site visit with purchasing.	Sam Carter
117	175	1995-05-21	meeting	Site visit with purchasing.	Anna Weber
118	1327	1995-05-24	complaint	Late delivery on two order lines.	Priya Shah
119	229	1995-05-25	meeting	Quarterly business review.	Priya Shah
120	625	1995-05-25	complaint	Late delivery on two order lines.	Claire Martin
121	643	1995-05-25	meeting	Quarterly business review.	Sam Carter
122	71	1995-05-25	support	Requested updated price list.	Sam Carter
123	1006	1995-05-30	support	Requested updated price list.	Luca Rossi
124	70	1995-05-31	meeting	Quarterly business review.	Sam Carter
125	1368	1995-06-02	meeting	Quarterly business review.	Diego Santos
126	84	1995-06-02	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
127	1009	1995-06-03	meeting	Site visit with purchasing.	Tom Becker
128	392	1995-06-04	meeting	Quarterly business review.	Anna Weber
129	963	1995-06-05	complaint	Late delivery on two order lines.	Claire Martin
130	655	1995-06-05	complaint	Invoice dispute, resolved.	Diego Santos
131	929	1995-06-07	complaint	Late delivery on two order lines.	Priya Shah
132	403	1995-06-07	complaint	Invoice dispute, resolved.	Sam Carter
133	1302	1995-06-07	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
134	1426	1995-06-08	support	Requested updated price list.	Tom Becker
135	991	1995-06-09	meeting	Quarterly business review.	Claire Martin
136	487	1995-06-09	meeting	Site visit with purchasing.	Priya Shah
137	1415	1995-06-10	complaint	Invoice dispute, resolved.	Diego Santos
138	353	1995-06-14	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
139	332	1995-06-14	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
140	1482	1995-06-15	complaint	Late delivery on two order lines.	Diego Santos
141	1475	1995-06-16	meeting	Site visit with purchasing.	Luca Rossi
142	846	1995-06-17	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
143	1081	1995-06-17	meeting	Quarterly business review.	Priya Shah
144	1072	1995-06-18	meeting	Site visit with purchasing.	Diego Santos
145	44	1995-06-21	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
146	1057	1995-06-21	support	Requested updated price list.	Tom Becker
147	339	1995-06-21	complaint	Invoice dispute, resolved.	Diego Santos
148	113	1995-06-21	complaint	Invoice dispute, resolved.	Tom Becker
149	679	1995-06-24	complaint	Invoice dispute, resolved.	Sam Carter
150	134	1995-06-26	complaint	Invoice dispute, resolved.	Luca Rossi
151	492	1995-06-28	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
152	1356	1995-06-29	support	Requested updated price list.	Claire Martin
153	1157	1995-06-29	support	Requested updated price list.	Sam Carter
154	878	1995-06-29	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
155	597	1995-06-29	meeting	Site visit with purchasing.	Mei Lin
156	1065	1995-07-02	complaint	Invoice dispute, resolved.	Luca Rossi
157	178	1995-07-04	complaint	Invoice dispute, resolved.	Tom Becker
158	669	1995-07-05	complaint	Invoice dispute, resolved.	Priya Shah
159	1047	1995-07-08	meeting	Quarterly business review.	Claire Martin
160	898	1995-07-09	meeting	Quarterly business review.	Sam Carter
161	792	1995-07-10	complaint	Late delivery on two order lines.	Diego Santos
162	27	1995-07-10	support	Requested updated price list.	Claire Martin
163	1075	1995-07-17	complaint	Invoice dispute, resolved.	Tom Becker
164	854	1995-07-20	meeting	Site visit with purchasing.	Luca Rossi
165	815	1995-07-23	complaint	Invoice dispute, resolved.	Anna Weber
166	784	1995-07-23	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
167	410	1995-07-23	complaint	Invoice dispute, resolved.	Priya Shah
168	1230	1995-07-25	complaint	Late delivery on two order lines.	Claire Martin
169	215	1995-07-27	complaint	Late delivery on two order lines.	Priya Shah
170	1145	1995-07-30	complaint	Late delivery on two order lines.	Anna Weber
171	358	1995-07-31	complaint	Invoice dispute, resolved.	Priya Shah
172	331	1995-07-31	meeting	Site visit with purchasing.	Luca Rossi
173	1052	1995-08-01	support	Requested updated price list.	Tom Becker
174	1466	1995-08-02	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
175	781	1995-08-03	complaint	Late delivery on two order lines.	Mei Lin
176	565	1995-08-05	complaint	Late delivery on two order lines.	Luca Rossi
177	1462	1995-08-09	support	Requested updated price list.	Anna Weber
178	1322	1995-08-09	complaint	Invoice dispute, resolved.	Priya Shah
179	1193	1995-08-09	support	Requested updated price list.	Priya Shah
180	438	1995-08-10	meeting	Site visit with purchasing.	Luca Rossi
181	625	1995-08-12	complaint	Late delivery on two order lines.	Claire Martin
182	471	1995-08-12	meeting	Quarterly business review.	Mei Lin
183	868	1995-08-16	meeting	Quarterly business review.	Tom Becker
184	639	1995-08-16	support	Requested updated price list.	Luca Rossi
185	915	1995-08-18	meeting	Quarterly business review.	Claire Martin
186	173	1995-08-22	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
187	343	1995-08-23	meeting	Site visit with purchasing.	Sam Carter
188	820	1995-08-23	complaint	Invoice dispute, resolved.	Luca Rossi
189	784	1995-08-23	meeting	Site visit with purchasing.	Anna Weber
190	930	1995-08-24	complaint	Late delivery on two order lines.	Priya Shah
191	124	1995-08-25	complaint	Invoice dispute, resolved.	Tom Becker
192	34	1995-08-26	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
193	1062	1995-08-27	complaint	Invoice dispute, resolved.	Tom Becker
194	291	1995-08-27	complaint	Invoice dispute, resolved.	Claire Martin
195	919	1995-08-28	complaint	Invoice dispute, resolved.	Diego Santos
196	562	1995-08-29	meeting	Site visit with purchasing.	Diego Santos
197	404	1995-08-31	complaint	Late delivery on two order lines.	Mei Lin
198	902	1995-08-31	meeting	Quarterly business review.	Claire Martin
199	1325	1995-09-02	complaint	Late delivery on two order lines.	Mei Lin
200	1196	1995-09-03	meeting	Quarterly business review.	Claire Martin
201	1180	1995-09-05	support	Requested updated price list.	Tom Becker
202	133	1995-09-06	complaint	Invoice dispute, resolved.	Priya Shah
203	1088	1995-09-06	meeting	Quarterly business review.	Diego Santos
204	1192	1995-09-08	complaint	Late delivery on two order lines.	Claire Martin
205	1006	1995-09-09	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
206	392	1995-09-12	meeting	Site visit with purchasing.	Anna Weber
207	651	1995-09-12	complaint	Invoice dispute, resolved.	Claire Martin
208	550	1995-09-15	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
209	1229	1995-09-15	meeting	Quarterly business review.	Anna Weber
210	1044	1995-09-16	meeting	Quarterly business review.	Anna Weber
211	548	1995-09-18	meeting	Quarterly business review.	Anna Weber
212	584	1995-09-19	meeting	Site visit with purchasing.	Tom Becker
213	534	1995-09-21	meeting	Site visit with purchasing.	Priya Shah
214	985	1995-09-23	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
215	668	1995-09-24	meeting	Quarterly business review.	Tom Becker
216	44	1995-09-26	complaint	Invoice dispute, resolved.	Claire Martin
217	155	1995-09-27	meeting	Site visit with purchasing.	Diego Santos
218	927	1995-09-30	meeting	Site visit with purchasing.	Mei Lin
219	507	1995-10-01	complaint	Invoice dispute, resolved.	Mei Lin
220	1057	1995-10-04	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
221	643	1995-10-04	support	Requested updated price list.	Sam Carter
222	1454	1995-10-05	complaint	Late delivery on two order lines.	Tom Becker
223	228	1995-10-05	support	Requested updated price list.	Priya Shah
224	542	1995-10-05	meeting	Site visit with purchasing.	Sam Carter
225	195	1995-10-07	meeting	Site visit with purchasing.	Priya Shah
226	872	1995-10-07	support	Requested updated price list.	Luca Rossi
227	835	1995-10-09	support	Requested updated price list.	Luca Rossi
228	252	1995-10-10	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
229	982	1995-10-10	meeting	Site visit with purchasing.	Diego Santos
230	252	1995-10-13	meeting	Site visit with purchasing.	Sam Carter
231	1145	1995-10-14	complaint	Invoice dispute, resolved.	Anna Weber
232	135	1995-10-15	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
233	411	1995-10-15	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
234	354	1995-10-15	complaint	Late delivery on two order lines.	Mei Lin
235	7	1995-10-17	meeting	Site visit with purchasing.	Anna Weber
236	1043	1995-10-18	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
237	187	1995-10-18	complaint	Invoice dispute, resolved.	Luca Rossi
238	1498	1995-10-20	complaint	Late delivery on two order lines.	Diego Santos
239	1061	1995-10-20	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
240	1477	1995-10-21	complaint	Invoice dispute, resolved.	Mei Lin
241	500	1995-10-22	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
242	1043	1995-10-22	complaint	Invoice dispute, resolved.	Anna Weber
243	318	1995-10-22	meeting	Site visit with purchasing.	Anna Weber
244	1488	1995-10-23	meeting	Quarterly business review.	Tom Becker
245	799	1995-10-23	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
246	1381	1995-10-26	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
247	410	1995-10-26	meeting	Quarterly business review.	Priya Shah
248	848	1995-10-26	meeting	Quarterly business review.	Tom Becker
249	43	1995-10-27	complaint	Invoice dispute, resolved.	Anna Weber
250	1396	1995-10-30	complaint	Late delivery on two order lines.	Claire Martin
251	1403	1995-11-05	support	Requested updated price list.	Anna Weber
252	1251	1995-11-05	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
253	1489	1995-11-05	complaint	Late delivery on two order lines.	Sam Carter
254	756	1995-11-07	meeting	Quarterly business review.	Claire Martin
255	76	1995-11-08	meeting	Site visit with purchasing.	Claire Martin
256	1152	1995-11-09	meeting	Quarterly business review.	Tom Becker
257	833	1995-11-10	complaint	Invoice dispute, resolved.	Mei Lin
258	489	1995-11-14	meeting	Quarterly business review.	Priya Shah
259	1351	1995-11-15	complaint	Invoice dispute, resolved.	Claire Martin
260	496	1995-11-17	complaint	Late delivery on two order lines.	Luca Rossi
261	700	1995-11-17	meeting	Site visit with purchasing.	Claire Martin
262	1067	1995-11-18	meeting	Site visit with purchasing.	Luca Rossi
263	331	1995-11-19	support	Requested updated price list.	Luca Rossi
264	350	1995-11-20	meeting	Quarterly business review.	Anna Weber
265	589	1995-11-20	support	Requested updated price list.	Anna Weber
266	717	1995-11-21	meeting	Quarterly business review.	Sam Carter
267	247	1995-11-24	meeting	Quarterly business review.	Diego Santos
268	1264	1995-11-25	support	Requested updated price list.	Luca Rossi
269	759	1995-11-27	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
270	994	1995-12-01	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
271	625	1995-12-01	complaint	Late delivery on two order lines.	Claire Martin
272	1176	1995-12-03	complaint	Late delivery on two order lines.	Tom Becker
273	1170	1995-12-05	complaint	Late delivery on two order lines.	Sam Carter
274	107	1995-12-07	meeting	Site visit with purchasing.	Priya Shah
275	799	1995-12-07	meeting	Quarterly business review.	Claire Martin
276	375	1995-12-08	meeting	Site visit with purchasing.	Tom Becker
277	995	1995-12-09	complaint	Invoice dispute, resolved.	Claire Martin
278	1002	1995-12-09	complaint	Late delivery on two order lines.	Diego Santos
279	1421	1995-12-10	support	Requested updated price list.	Mei Lin
280	1325	1995-12-11	complaint	Late delivery on two order lines.	Mei Lin
281	434	1995-12-14	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
282	733	1995-12-16	support	Requested updated price list.	Anna Weber
283	1316	1995-12-19	support	Requested updated price list.	Sam Carter
284	613	1995-12-20	meeting	Site visit with purchasing.	Claire Martin
285	993	1995-12-20	complaint	Invoice dispute, resolved.	Anna Weber
286	222	1995-12-20	meeting	Quarterly business review.	Mei Lin
287	944	1995-12-22	meeting	Site visit with purchasing.	Luca Rossi
288	1247	1995-12-23	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
289	1133	1995-12-25	meeting	Site visit with purchasing.	Claire Martin
290	273	1995-12-26	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
291	1010	1995-12-27	complaint	Late delivery on two order lines.	Claire Martin
292	1007	1995-12-30	support	Requested updated price list.	Anna Weber
293	1401	1995-12-31	complaint	Invoice dispute, resolved.	Priya Shah
294	105	1996-01-03	support	Requested updated price list.	Tom Becker
295	1092	1996-01-04	complaint	Late delivery on two order lines.	Luca Rossi
296	103	1996-01-05	meeting	Site visit with purchasing.	Luca Rossi
297	895	1996-01-06	support	Requested updated price list.	Diego Santos
298	545	1996-01-07	meeting	Site visit with purchasing.	Mei Lin
299	210	1996-01-09	complaint	Invoice dispute, resolved.	Priya Shah
300	774	1996-01-10	meeting	Quarterly business review.	Diego Santos
301	107	1996-01-11	support	Requested updated price list.	Priya Shah
302	783	1996-01-13	support	Requested updated price list.	Diego Santos
303	104	1996-01-15	meeting	Quarterly business review.	Anna Weber
304	1253	1996-01-19	meeting	Quarterly business review.	Diego Santos
305	1376	1996-01-20	meeting	Quarterly business review.	Diego Santos
306	4	1996-01-21	support	Requested updated price list.	Priya Shah
307	756	1996-01-21	meeting	Quarterly business review.	Claire Martin
308	500	1996-01-22	meeting	Site visit with purchasing.	Mei Lin
309	490	1996-01-22	meeting	Site visit with purchasing.	Diego Santos
310	98	1996-01-23	meeting	Quarterly business review.	Tom Becker
311	1423	1996-01-26	meeting	Site visit with purchasing.	Mei Lin
312	178	1996-01-26	complaint	Late delivery on two order lines.	Tom Becker
313	582	1996-01-27	complaint	Invoice dispute, resolved.	Priya Shah
314	567	1996-01-30	complaint	Late delivery on two order lines.	Anna Weber
315	663	1996-01-30	meeting	Quarterly business review.	Priya Shah
316	121	1996-01-31	meeting	Site visit with purchasing.	Luca Rossi
317	702	1996-02-02	support	Requested updated price list.	Tom Becker
318	423	1996-02-08	complaint	Invoice dispute, resolved.	Luca Rossi
319	14	1996-02-09	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
320	469	1996-02-12	complaint	Invoice dispute, resolved.	Priya Shah
321	1164	1996-02-12	meeting	Site visit with purchasing.	Sam Carter
322	886	1996-02-13	complaint	Invoice dispute, resolved.	Anna Weber
323	678	1996-02-16	complaint	Invoice dispute, resolved.	Priya Shah
324	48	1996-02-18	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
325	997	1996-02-19	support	Requested updated price list.	Luca Rossi
326	75	1996-02-21	complaint	Invoice dispute, resolved.	Diego Santos
327	656	1996-02-22	meeting	Site visit with purchasing.	Diego Santos
328	1490	1996-02-23	complaint	Invoice dispute, resolved.	Anna Weber
329	725	1996-02-26	complaint	Late delivery on two order lines.	Priya Shah
330	446	1996-03-02	meeting	Site visit with purchasing.	Priya Shah
331	1174	1996-03-03	complaint	Late delivery on two order lines.	Claire Martin
332	205	1996-03-03	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
333	1110	1996-03-08	meeting	Quarterly business review.	Sam Carter
334	750	1996-03-08	meeting	Quarterly business review.	Mei Lin
335	794	1996-03-08	meeting	Site visit with purchasing.	Sam Carter
336	487	1996-03-09	support	Requested updated price list.	Priya Shah
337	1365	1996-03-09	complaint	Late delivery on two order lines.	Priya Shah
338	536	1996-03-10	complaint	Invoice dispute, resolved.	Priya Shah
339	207	1996-03-10	complaint	Invoice dispute, resolved.	Claire Martin
340	1015	1996-03-11	meeting	Site visit with purchasing.	Diego Santos
341	1501	1996-03-12	complaint	Escalation: repeated late deliveries on fleet parts; customer reviewing suppliers.	Anna Weber
342	1502	1996-03-12	complaint	Escalation: repeated late deliveries on fleet parts; customer reviewing suppliers.	Anna Weber
343	1503	1996-03-12	complaint	Escalation: repeated late deliveries on fleet parts; customer reviewing suppliers.	Anna Weber
344	173	1996-03-14	complaint	Late delivery on two order lines.	Priya Shah
345	52	1996-03-17	complaint	Late delivery on two order lines.	Tom Becker
346	889	1996-03-17	meeting	Site visit with purchasing.	Mei Lin
347	362	1996-03-18	complaint	Invoice dispute, resolved.	Priya Shah
348	948	1996-03-21	support	Requested updated price list.	Tom Becker
349	1053	1996-03-22	complaint	Late delivery on two order lines.	Diego Santos
350	68	1996-03-27	meeting	Site visit with purchasing.	Tom Becker
351	291	1996-03-28	support	Requested updated price list.	Claire Martin
352	1448	1996-03-28	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
353	976	1996-03-29	meeting	Quarterly business review.	Priya Shah
354	990	1996-03-30	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
355	772	1996-04-01	support	Requested updated price list.	Claire Martin
356	182	1996-04-03	complaint	Late delivery on two order lines.	Tom Becker
357	676	1996-04-04	meeting	Site visit with purchasing.	Tom Becker
358	1007	1996-04-04	complaint	Invoice dispute, resolved.	Anna Weber
359	629	1996-04-04	meeting	Quarterly business review.	Sam Carter
360	1330	1996-04-05	meeting	Quarterly business review.	Luca Rossi
361	725	1996-04-06	meeting	Quarterly business review.	Priya Shah
362	1242	1996-04-07	meeting	Quarterly business review.	Priya Shah
363	1045	1996-04-08	support	Requested updated price list.	Claire Martin
364	930	1996-04-10	support	Requested updated price list.	Priya Shah
365	60	1996-04-10	support	Requested updated price list.	Anna Weber
366	368	1996-04-11	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
367	232	1996-04-11	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
368	816	1996-04-12	meeting	Quarterly business review.	Anna Weber
369	670	1996-04-12	meeting	Quarterly business review.	Tom Becker
370	1287	1996-04-13	meeting	Quarterly business review.	Sam Carter
371	1046	1996-04-15	support	Requested updated price list.	Tom Becker
372	1070	1996-04-16	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
373	1244	1996-04-19	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
374	1014	1996-04-20	support	Requested updated price list.	Mei Lin
375	232	1996-04-20	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
376	885	1996-04-24	complaint	Invoice dispute, resolved.	Priya Shah
377	943	1996-04-24	complaint	Late delivery on two order lines.	Luca Rossi
378	590	1996-04-27	support	Requested updated price list.	Claire Martin
379	145	1996-04-28	complaint	Invoice dispute, resolved.	Luca Rossi
380	1286	1996-04-30	complaint	Late delivery on two order lines.	Luca Rossi
381	1309	1996-05-01	complaint	Late delivery on two order lines.	Mei Lin
382	217	1996-05-01	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
383	343	1996-05-07	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
384	1489	1996-05-08	complaint	Late delivery on two order lines.	Sam Carter
385	620	1996-05-08	complaint	Late delivery on two order lines.	Mei Lin
386	1504	1996-05-08	meeting	Site visit with purchasing.	Sam Carter
387	1142	1996-05-11	complaint	Late delivery on two order lines.	Priya Shah
388	532	1996-05-12	complaint	Invoice dispute, resolved.	Mei Lin
389	940	1996-05-12	complaint	Invoice dispute, resolved.	Claire Martin
390	1327	1996-05-14	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
391	646	1996-05-14	meeting	Quarterly business review.	Tom Becker
392	1351	1996-05-18	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
393	134	1996-05-18	complaint	Late delivery on two order lines.	Luca Rossi
394	975	1996-05-18	support	Requested updated price list.	Mei Lin
395	19	1996-05-19	support	Requested updated price list.	Priya Shah
396	498	1996-05-20	meeting	Quarterly business review.	Diego Santos
397	1501	1996-05-20	tender	Annual fleet-parts tender opened; we submitted a bid.	Anna Weber
398	1502	1996-05-20	tender	Annual fleet-parts tender opened; we submitted a bid.	Anna Weber
399	1503	1996-05-20	tender	Annual fleet-parts tender opened; we submitted a bid.	Anna Weber
400	579	1996-05-21	meeting	Quarterly business review.	Diego Santos
401	672	1996-05-21	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
402	810	1996-05-22	support	Requested updated price list.	Mei Lin
403	1000	1996-05-22	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
404	1461	1996-05-22	complaint	Late delivery on two order lines.	Tom Becker
405	1008	1996-05-23	meeting	Quarterly business review.	Claire Martin
406	1155	1996-05-23	complaint	Invoice dispute, resolved.	Tom Becker
407	498	1996-05-23	complaint	Invoice dispute, resolved.	Diego Santos
408	1057	1996-05-26	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
409	67	1996-05-26	complaint	Invoice dispute, resolved.	Anna Weber
410	1489	1996-05-27	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
411	597	1996-05-28	support	Requested updated price list.	Mei Lin
412	959	1996-05-29	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
413	212	1996-05-31	complaint	Late delivery on two order lines.	Diego Santos
414	124	1996-06-02	complaint	Late delivery on two order lines.	Tom Becker
415	1191	1996-06-03	complaint	Invoice dispute, resolved.	Anna Weber
416	1463	1996-06-04	complaint	Invoice dispute, resolved.	Anna Weber
417	1043	1996-06-04	meeting	Site visit with purchasing.	Anna Weber
418	1008	1996-06-07	meeting	Quarterly business review.	Claire Martin
419	1272	1996-06-07	complaint	Late delivery on two order lines.	Claire Martin
420	173	1996-06-07	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
421	1369	1996-06-11	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
422	821	1996-06-13	complaint	Late delivery on two order lines.	Anna Weber
423	895	1996-06-16	complaint	Late delivery on two order lines.	Diego Santos
424	1376	1996-06-16	complaint	Late delivery on two order lines.	Diego Santos
425	1027	1996-06-20	meeting	Quarterly business review.	Sam Carter
426	314	1996-06-24	support	Requested updated price list.	Claire Martin
427	335	1996-06-25	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
428	280	1996-06-25	meeting	Quarterly business review.	Sam Carter
429	1201	1996-06-26	meeting	Quarterly business review.	Mei Lin
430	1503	1996-06-26	meeting	Site visit with purchasing.	Anna Weber
431	1159	1996-06-28	support	Requested updated price list.	Mei Lin
432	598	1996-06-28	support	Requested updated price list.	Anna Weber
433	692	1996-06-28	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
434	1501	1996-06-28	contract_ended	Lost the annual fleet-parts tender to a lower-cost competitor. Final deliveries end of June; no orders expected from July.	Anna Weber
435	1502	1996-06-28	contract_ended	Lost the annual fleet-parts tender to a lower-cost competitor. Final deliveries end of June; no orders expected from July.	Anna Weber
436	1503	1996-06-28	contract_ended	Lost the annual fleet-parts tender to a lower-cost competitor. Final deliveries end of June; no orders expected from July.	Anna Weber
437	1169	1996-06-29	meeting	Site visit with purchasing.	Tom Becker
438	1101	1996-06-30	meeting	Quarterly business review.	Tom Becker
439	626	1996-07-07	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
440	732	1996-07-07	complaint	Late delivery on two order lines.	Tom Becker
441	805	1996-07-11	complaint	Late delivery on two order lines.	Luca Rossi
442	535	1996-07-11	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
443	470	1996-07-11	meeting	Site visit with purchasing.	Sam Carter
444	78	1996-07-12	complaint	Late delivery on two order lines.	Luca Rossi
445	1108	1996-07-12	meeting	Quarterly business review.	Mei Lin
446	346	1996-07-12	complaint	Invoice dispute, resolved.	Mei Lin
447	206	1996-07-13	support	Requested updated price list.	Anna Weber
448	1246	1996-07-14	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
449	707	1996-07-18	support	Requested updated price list.	Diego Santos
450	762	1996-07-19	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
451	899	1996-07-19	complaint	Invoice dispute, resolved.	Priya Shah
452	1076	1996-07-20	meeting	Site visit with purchasing.	Sam Carter
453	453	1996-07-21	support	Requested updated price list.	Anna Weber
454	1135	1996-07-21	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
455	55	1996-07-22	complaint	Late delivery on two order lines.	Luca Rossi
456	769	1996-07-22	complaint	Invoice dispute, resolved.	Tom Becker
457	895	1996-07-22	support	Requested updated price list.	Diego Santos
458	707	1996-07-24	meeting	Quarterly business review.	Diego Santos
459	1409	1996-07-24	support	Requested updated price list.	Sam Carter
460	856	1996-07-24	complaint	Invoice dispute, resolved.	Sam Carter
461	1435	1996-07-26	meeting	Site visit with purchasing.	Anna Weber
462	778	1996-07-29	support	Requested updated price list.	Luca Rossi
463	1468	1996-07-29	meeting	Quarterly business review.	Priya Shah
464	501	1996-07-30	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
465	1461	1996-08-01	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
466	30	1996-08-02	complaint	Late delivery on two order lines.	Priya Shah
467	374	1996-08-04	support	Requested updated price list.	Mei Lin
468	483	1996-08-06	support	Requested updated price list.	Sam Carter
469	468	1996-08-07	meeting	Site visit with purchasing.	Diego Santos
470	1096	1996-08-07	complaint	Late delivery on two order lines.	Anna Weber
471	549	1996-08-09	meeting	Quarterly business review.	Anna Weber
472	1014	1996-08-10	complaint	Late delivery on two order lines.	Mei Lin
473	667	1996-08-10	complaint	Late delivery on two order lines.	Mei Lin
474	309	1996-08-11	complaint	Late delivery on two order lines.	Sam Carter
475	517	1996-08-12	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
476	390	1996-08-17	support	Requested updated price list.	Priya Shah
477	1349	1996-08-25	complaint	Late delivery on two order lines.	Priya Shah
478	1278	1996-08-28	meeting	Site visit with purchasing.	Mei Lin
479	533	1996-08-28	support	Requested updated price list.	Priya Shah
480	617	1996-08-29	complaint	Late delivery on two order lines.	Mei Lin
481	1227	1996-09-01	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
482	499	1996-09-01	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
483	358	1996-09-03	complaint	Late delivery on two order lines.	Priya Shah
484	323	1996-09-03	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
485	1383	1996-09-07	meeting	Quarterly business review.	Diego Santos
486	1232	1996-09-08	complaint	Late delivery on two order lines.	Priya Shah
487	818	1996-09-08	complaint	Late delivery on two order lines.	Mei Lin
488	1476	1996-09-10	meeting	Site visit with purchasing.	Claire Martin
489	1140	1996-09-10	complaint	Late delivery on two order lines.	Luca Rossi
490	11	1996-09-14	support	Requested updated price list.	Luca Rossi
491	441	1996-09-15	meeting	Quarterly business review.	Tom Becker
492	227	1996-09-16	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
493	521	1996-09-18	complaint	Late delivery on two order lines.	Luca Rossi
494	477	1996-09-22	support	Requested updated price list.	Mei Lin
495	629	1996-09-22	complaint	Invoice dispute, resolved.	Sam Carter
496	116	1996-09-25	complaint	Late delivery on two order lines.	Sam Carter
497	98	1996-09-25	complaint	Late delivery on two order lines.	Tom Becker
498	165	1996-09-26	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
499	141	1996-09-28	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
500	794	1996-10-01	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
501	493	1996-10-02	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
502	900	1996-10-02	complaint	Late delivery on two order lines.	Priya Shah
503	1077	1996-10-03	support	Requested updated price list.	Tom Becker
504	393	1996-10-04	meeting	Site visit with purchasing.	Claire Martin
505	226	1996-10-05	meeting	Site visit with purchasing.	Anna Weber
506	622	1996-10-07	complaint	Late delivery on two order lines.	Priya Shah
507	1008	1996-10-08	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
508	1297	1996-10-10	meeting	Quarterly business review.	Luca Rossi
509	372	1996-10-11	meeting	Site visit with purchasing.	Tom Becker
510	774	1996-10-13	meeting	Site visit with purchasing.	Diego Santos
511	550	1996-10-14	support	Requested updated price list.	Priya Shah
512	1248	1996-10-16	meeting	Site visit with purchasing.	Mei Lin
513	292	1996-10-19	complaint	Invoice dispute, resolved.	Priya Shah
514	273	1996-10-19	complaint	Invoice dispute, resolved.	Luca Rossi
515	787	1996-10-21	complaint	Late delivery on two order lines.	Sam Carter
516	633	1996-10-26	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
517	1095	1996-10-26	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
518	518	1996-10-27	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
519	903	1996-10-28	complaint	Invoice dispute, resolved.	Claire Martin
520	532	1996-10-28	support	Requested updated price list.	Mei Lin
521	1347	1996-10-28	meeting	Quarterly business review.	Sam Carter
522	1334	1996-10-30	complaint	Invoice dispute, resolved.	Mei Lin
523	181	1996-11-01	complaint	Invoice dispute, resolved.	Mei Lin
524	530	1996-11-01	complaint	Late delivery on two order lines.	Mei Lin
525	145	1996-11-02	complaint	Invoice dispute, resolved.	Luca Rossi
526	1335	1996-11-04	complaint	Invoice dispute, resolved.	Sam Carter
527	49	1996-11-04	meeting	Quarterly business review.	Mei Lin
528	212	1996-11-04	meeting	Quarterly business review.	Diego Santos
529	771	1996-11-05	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
530	1504	1996-11-05	tender	Bid on the multi-year maintenance-parts contract.	Sam Carter
531	1505	1996-11-05	tender	Bid on the multi-year maintenance-parts contract.	Sam Carter
532	1283	1996-11-07	complaint	Late delivery on two order lines.	Claire Martin
533	188	1996-11-08	complaint	Late delivery on two order lines.	Claire Martin
534	38	1996-11-08	meeting	Site visit with purchasing.	Diego Santos
535	1075	1996-11-08	meeting	Quarterly business review.	Tom Becker
536	1504	1996-11-11	complaint	Late delivery on two order lines.	Sam Carter
537	1344	1996-11-12	meeting	Quarterly business review.	Priya Shah
538	338	1996-11-13	complaint	Invoice dispute, resolved.	Priya Shah
539	795	1996-11-14	meeting	Site visit with purchasing.	Tom Becker
540	570	1996-11-15	support	Requested updated price list.	Anna Weber
541	934	1996-11-15	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
542	964	1996-11-16	meeting	Site visit with purchasing.	Mei Lin
543	1304	1996-11-19	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
544	1168	1996-11-19	complaint	Late delivery on two order lines.	Priya Shah
545	239	1996-11-23	meeting	Site visit with purchasing.	Sam Carter
546	413	1996-11-25	complaint	Invoice dispute, resolved.	Mei Lin
547	500	1996-11-26	meeting	Site visit with purchasing.	Mei Lin
548	1340	1996-11-27	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
549	1232	1996-11-29	complaint	Invoice dispute, resolved.	Priya Shah
550	484	1996-11-29	support	Requested updated price list.	Tom Becker
551	798	1996-12-01	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
552	1418	1996-12-01	complaint	Invoice dispute, resolved.	Luca Rossi
553	1197	1996-12-01	meeting	Quarterly business review.	Anna Weber
554	257	1996-12-02	support	Requested updated price list.	Priya Shah
555	740	1996-12-04	complaint	Late delivery on two order lines.	Priya Shah
556	143	1996-12-05	support	Requested updated price list.	Priya Shah
557	1126	1996-12-06	meeting	Site visit with purchasing.	Luca Rossi
558	724	1996-12-08	meeting	Site visit with purchasing.	Sam Carter
559	975	1996-12-08	meeting	Quarterly business review.	Mei Lin
560	370	1996-12-09	complaint	Invoice dispute, resolved.	Sam Carter
561	886	1996-12-10	price_renegotiated	Enrolled in the winter volume-discount programme: extra 8% off all lines from January to March 1997, in exchange for higher volumes.	Anna Weber
562	265	1996-12-10	price_renegotiated	Enrolled in the winter volume-discount programme: extra 8% off all lines from January to March 1997, in exchange for higher volumes.	Priya Shah
563	305	1996-12-10	price_renegotiated	Enrolled in the winter volume-discount programme: extra 8% off all lines from January to March 1997, in exchange for higher volumes.	Tom Becker
564	869	1996-12-10	price_renegotiated	Enrolled in the winter volume-discount programme: extra 8% off all lines from January to March 1997, in exchange for higher volumes.	Claire Martin
565	310	1996-12-10	price_renegotiated	Enrolled in the winter volume-discount programme: extra 8% off all lines from January to March 1997, in exchange for higher volumes.	Luca Rossi
566	100	1996-12-10	price_renegotiated	Enrolled in the winter volume-discount programme: extra 8% off all lines from January to March 1997, in exchange for higher volumes.	Sam Carter
567	1091	1996-12-10	price_renegotiated	Enrolled in the winter volume-discount programme: extra 8% off all lines from January to March 1997, in exchange for higher volumes.	Tom Becker
568	830	1996-12-10	price_renegotiated	Enrolled in the winter volume-discount programme: extra 8% off all lines from January to March 1997, in exchange for higher volumes.	Diego Santos
569	576	1996-12-17	complaint	Invoice dispute, resolved.	Diego Santos
570	1504	1996-12-18	new_contract	Won the multi-year maintenance-parts contract. Large monthly orders start in January 1997.	Sam Carter
571	1505	1996-12-18	new_contract	Won the multi-year maintenance-parts contract. Large monthly orders start in January 1997.	Sam Carter
572	930	1996-12-19	meeting	Site visit with purchasing.	Priya Shah
573	525	1996-12-19	complaint	Invoice dispute, resolved.	Mei Lin
574	98	1996-12-21	complaint	Late delivery on two order lines.	Tom Becker
575	1222	1996-12-22	complaint	Invoice dispute, resolved.	Diego Santos
576	1252	1996-12-24	support	Requested updated price list.	Priya Shah
577	161	1996-12-24	support	Requested updated price list.	Anna Weber
578	732	1996-12-25	meeting	Quarterly business review.	Tom Becker
579	959	1996-12-28	meeting	Site visit with purchasing.	Claire Martin
580	617	1996-12-29	meeting	Site visit with purchasing.	Mei Lin
581	1421	1996-12-29	complaint	Late delivery on two order lines.	Mei Lin
582	1164	1996-12-30	support	Requested updated price list.	Sam Carter
583	412	1997-01-01	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
584	1103	1997-01-01	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
585	155	1997-01-02	meeting	Site visit with purchasing.	Diego Santos
586	30	1997-01-07	support	Requested updated price list.	Priya Shah
587	200	1997-01-07	complaint	Invoice dispute, resolved.	Anna Weber
588	1419	1997-01-07	meeting	Quarterly business review.	Priya Shah
589	49	1997-01-07	support	Requested updated price list.	Mei Lin
590	589	1997-01-08	support	Requested updated price list.	Anna Weber
591	1292	1997-01-09	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
592	872	1997-01-10	support	Requested updated price list.	Luca Rossi
593	1199	1997-01-11	meeting	Site visit with purchasing.	Luca Rossi
594	535	1997-01-11	meeting	Quarterly business review.	Diego Santos
595	1138	1997-01-12	support	Requested updated price list.	Mei Lin
596	1191	1997-01-12	meeting	Quarterly business review.	Anna Weber
597	930	1997-01-15	meeting	Site visit with purchasing.	Priya Shah
598	397	1997-01-18	complaint	Late delivery on two order lines.	Sam Carter
599	1190	1997-01-18	complaint	Invoice dispute, resolved.	Tom Becker
600	1137	1997-01-20	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
601	1070	1997-01-21	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
602	832	1997-01-22	meeting	Site visit with purchasing.	Anna Weber
603	977	1997-01-22	complaint	Invoice dispute, resolved.	Diego Santos
604	59	1997-01-23	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
605	1219	1997-01-23	support	Requested updated price list.	Tom Becker
606	1300	1997-01-23	support	Requested updated price list.	Tom Becker
607	447	1997-01-24	complaint	Late delivery on two order lines.	Claire Martin
608	91	1997-01-26	complaint	Invoice dispute, resolved.	Diego Santos
609	443	1997-01-29	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
610	124	1997-01-31	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
611	1137	1997-02-02	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
612	1162	1997-02-02	meeting	Site visit with purchasing.	Sam Carter
613	11	1997-02-03	complaint	Invoice dispute, resolved.	Luca Rossi
614	675	1997-02-03	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
615	236	1997-02-03	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
616	1289	1997-02-03	meeting	Site visit with purchasing.	Diego Santos
617	1356	1997-02-05	meeting	Site visit with purchasing.	Claire Martin
618	893	1997-02-09	complaint	Invoice dispute, resolved.	Sam Carter
619	1391	1997-02-10	complaint	Late delivery on two order lines.	Priya Shah
620	1210	1997-02-11	complaint	Invoice dispute, resolved.	Mei Lin
621	359	1997-02-13	complaint	Invoice dispute, resolved.	Sam Carter
622	133	1997-02-15	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
623	846	1997-02-17	meeting	Quarterly business review.	Anna Weber
624	515	1997-02-17	complaint	Late delivery on two order lines.	Claire Martin
625	341	1997-02-17	support	Requested updated price list.	Claire Martin
626	135	1997-02-17	support	Requested updated price list.	Tom Becker
627	28	1997-02-18	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
628	1071	1997-02-18	meeting	Site visit with purchasing.	Luca Rossi
629	367	1997-02-19	complaint	Late delivery on two order lines.	Sam Carter
630	636	1997-02-20	support	Requested updated price list.	Diego Santos
631	922	1997-02-21	meeting	Quarterly business review.	Priya Shah
632	337	1997-02-22	support	Requested updated price list.	Mei Lin
633	942	1997-02-22	meeting	Quarterly business review.	Tom Becker
634	1264	1997-02-23	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
635	431	1997-02-24	meeting	Site visit with purchasing.	Tom Becker
636	427	1997-02-26	complaint	Invoice dispute, resolved.	Luca Rossi
637	1334	1997-02-26	meeting	Site visit with purchasing.	Mei Lin
638	1266	1997-02-26	complaint	Late delivery on two order lines.	Claire Martin
639	673	1997-02-26	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
640	1226	1997-03-03	meeting	Quarterly business review.	Tom Becker
641	1338	1997-03-06	meeting	Site visit with purchasing.	Luca Rossi
642	470	1997-03-06	meeting	Site visit with purchasing.	Sam Carter
643	765	1997-03-07	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
644	637	1997-03-07	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
645	383	1997-03-09	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
646	242	1997-03-10	complaint	Late delivery on two order lines.	Anna Weber
647	8	1997-03-12	meeting	Site visit with purchasing.	Claire Martin
648	486	1997-03-12	complaint	Late delivery on two order lines.	Tom Becker
649	503	1997-03-13	support	Requested updated price list.	Priya Shah
650	896	1997-03-15	complaint	Late delivery on two order lines.	Priya Shah
651	494	1997-03-16	complaint	Late delivery on two order lines.	Luca Rossi
652	1082	1997-03-17	meeting	Site visit with purchasing.	Priya Shah
653	1385	1997-03-17	complaint	Invoice dispute, resolved.	Priya Shah
654	84	1997-03-19	complaint	Invoice dispute, resolved.	Mei Lin
655	958	1997-03-19	support	Requested updated price list.	Claire Martin
656	760	1997-03-20	meeting	Site visit with purchasing.	Diego Santos
657	643	1997-03-21	support	Requested updated price list.	Sam Carter
658	403	1997-03-21	support	Requested updated price list.	Sam Carter
659	349	1997-03-21	complaint	Late delivery on two order lines.	Priya Shah
660	505	1997-03-22	complaint	Late delivery on two order lines.	Sam Carter
661	1254	1997-03-23	meeting	Quarterly business review.	Luca Rossi
662	780	1997-03-23	complaint	Invoice dispute, resolved.	Tom Becker
663	100	1997-03-26	support	Requested updated price list.	Sam Carter
664	643	1997-03-27	meeting	Site visit with purchasing.	Sam Carter
665	1102	1997-03-28	meeting	Quarterly business review.	Anna Weber
666	1357	1997-03-29	complaint	Late delivery on two order lines.	Priya Shah
667	373	1997-03-29	complaint	Late delivery on two order lines.	Tom Becker
668	765	1997-03-30	meeting	Site visit with purchasing.	Sam Carter
669	434	1997-04-02	support	Requested updated price list.	Priya Shah
670	713	1997-04-05	meeting	Quarterly business review.	Priya Shah
671	521	1997-04-06	meeting	Quarterly business review.	Luca Rossi
672	512	1997-04-06	support	Requested updated price list.	Tom Becker
673	436	1997-04-06	complaint	Invoice dispute, resolved.	Diego Santos
674	198	1997-04-08	support	Requested updated price list.	Priya Shah
675	721	1997-04-08	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
676	272	1997-04-08	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
677	525	1997-04-08	meeting	Quarterly business review.	Mei Lin
678	1041	1997-04-09	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
679	691	1997-04-09	complaint	Late delivery on two order lines.	Tom Becker
680	439	1997-04-09	support	Requested updated price list.	Anna Weber
681	72	1997-04-12	complaint	Invoice dispute, resolved.	Claire Martin
682	984	1997-04-20	complaint	Invoice dispute, resolved.	Claire Martin
683	627	1997-04-20	meeting	Site visit with purchasing.	Tom Becker
684	794	1997-04-21	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
685	1458	1997-04-24	complaint	Late delivery on two order lines.	Luca Rossi
686	873	1997-04-26	meeting	Site visit with purchasing.	Sam Carter
687	52	1997-04-26	meeting	Quarterly business review.	Tom Becker
688	804	1997-04-26	support	Requested updated price list.	Sam Carter
689	1391	1997-04-28	complaint	Late delivery on two order lines.	Priya Shah
690	361	1997-04-28	meeting	Quarterly business review.	Sam Carter
691	143	1997-04-29	support	Requested updated price list.	Priya Shah
692	943	1997-04-30	complaint	Invoice dispute, resolved.	Luca Rossi
693	1286	1997-04-30	complaint	Invoice dispute, resolved.	Luca Rossi
694	168	1997-04-30	complaint	Invoice dispute, resolved.	Mei Lin
695	501	1997-04-30	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
696	985	1997-05-03	complaint	Invoice dispute, resolved.	Mei Lin
697	762	1997-05-03	support	Requested updated price list.	Priya Shah
698	1046	1997-05-04	complaint	Late delivery on two order lines.	Tom Becker
699	169	1997-05-05	complaint	Invoice dispute, resolved.	Mei Lin
700	472	1997-05-05	complaint	Invoice dispute, resolved.	Mei Lin
701	644	1997-05-06	complaint	Late delivery on two order lines.	Sam Carter
702	98	1997-05-09	complaint	Late delivery on two order lines.	Tom Becker
703	411	1997-05-10	complaint	Late delivery on two order lines.	Priya Shah
704	124	1997-05-10	complaint	Invoice dispute, resolved.	Tom Becker
705	554	1997-05-11	complaint	Invoice dispute, resolved.	Sam Carter
706	1204	1997-05-12	complaint	Late delivery on two order lines.	Luca Rossi
707	7	1997-05-15	meeting	Quarterly business review.	Anna Weber
708	545	1997-05-16	complaint	Late delivery on two order lines.	Mei Lin
709	1423	1997-05-18	meeting	Site visit with purchasing.	Mei Lin
710	97	1997-05-19	meeting	Quarterly business review.	Luca Rossi
711	591	1997-05-19	complaint	Invoice dispute, resolved.	Luca Rossi
712	1047	1997-05-19	support	Requested updated price list.	Claire Martin
713	916	1997-05-20	complaint	Late delivery on two order lines.	Anna Weber
714	180	1997-05-20	meeting	Quarterly business review.	Claire Martin
715	901	1997-05-21	support	Requested updated price list.	Anna Weber
716	1400	1997-05-22	support	Requested updated price list.	Priya Shah
717	1325	1997-05-22	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
718	400	1997-05-25	support	Requested updated price list.	Anna Weber
719	864	1997-05-25	complaint	Invoice dispute, resolved.	Priya Shah
720	328	1997-05-26	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
721	289	1997-05-28	complaint	Late delivery on two order lines.	Anna Weber
722	1276	1997-05-29	support	Requested updated price list.	Sam Carter
723	973	1997-05-30	support	Requested updated price list.	Tom Becker
724	1095	1997-05-31	support	Requested updated price list.	Sam Carter
725	1479	1997-05-31	meeting	Site visit with purchasing.	Tom Becker
726	142	1997-06-01	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
727	295	1997-06-01	meeting	Quarterly business review.	Mei Lin
728	217	1997-06-02	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
729	48	1997-06-03	support	Requested updated price list.	Luca Rossi
730	911	1997-06-03	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
731	408	1997-06-03	complaint	Invoice dispute, resolved.	Priya Shah
732	1119	1997-06-03	meeting	Site visit with purchasing.	Claire Martin
733	424	1997-06-04	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
734	1076	1997-06-08	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
735	1060	1997-06-09	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
736	1418	1997-06-10	support	Requested updated price list.	Luca Rossi
737	925	1997-06-10	complaint	Invoice dispute, resolved.	Claire Martin
738	536	1997-06-12	support	Requested updated price list.	Priya Shah
739	624	1997-06-14	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
740	1501	1997-06-14	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
741	150	1997-06-16	meeting	Site visit with purchasing.	Tom Becker
742	1421	1997-06-16	meeting	Site visit with purchasing.	Mei Lin
743	201	1997-06-20	support	Requested updated price list.	Mei Lin
744	1368	1997-06-20	support	Requested updated price list.	Diego Santos
745	1205	1997-06-22	complaint	Late delivery on two order lines.	Tom Becker
746	746	1997-06-24	meeting	Quarterly business review.	Anna Weber
747	1156	1997-06-26	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
748	731	1997-06-27	support	Requested updated price list.	Claire Martin
749	1465	1997-06-28	complaint	Late delivery on two order lines.	Priya Shah
750	1163	1997-06-28	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
751	1404	1997-06-29	complaint	Invoice dispute, resolved.	Priya Shah
752	777	1997-06-30	complaint	Late delivery on two order lines.	Claire Martin
753	1342	1997-07-01	support	Requested updated price list.	Claire Martin
754	16	1997-07-03	meeting	Site visit with purchasing.	Sam Carter
755	243	1997-07-03	complaint	Late delivery on two order lines.	Mei Lin
756	471	1997-07-04	meeting	Site visit with purchasing.	Mei Lin
757	1382	1997-07-04	meeting	Site visit with purchasing.	Claire Martin
758	547	1997-07-04	complaint	Invoice dispute, resolved.	Diego Santos
759	576	1997-07-07	complaint	Invoice dispute, resolved.	Diego Santos
760	288	1997-07-07	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
761	1284	1997-07-08	meeting	Site visit with purchasing.	Anna Weber
762	724	1997-07-09	complaint	Invoice dispute, resolved.	Sam Carter
763	682	1997-07-09	meeting	Quarterly business review.	Mei Lin
764	490	1997-07-09	support	Requested updated price list.	Diego Santos
765	473	1997-07-09	meeting	Site visit with purchasing.	Tom Becker
766	739	1997-07-11	meeting	Site visit with purchasing.	Mei Lin
767	825	1997-07-13	support	Requested updated price list.	Claire Martin
768	490	1997-07-13	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
769	148	1997-07-14	complaint	Late delivery on two order lines.	Priya Shah
770	1082	1997-07-16	meeting	Site visit with purchasing.	Priya Shah
771	502	1997-07-19	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
772	747	1997-07-24	complaint	Late delivery on two order lines.	Claire Martin
773	934	1997-07-24	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
774	1384	1997-07-25	meeting	Quarterly business review.	Diego Santos
775	664	1997-07-26	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
776	465	1997-07-28	complaint	Invoice dispute, resolved.	Sam Carter
777	431	1997-07-28	meeting	Site visit with purchasing.	Tom Becker
778	1300	1997-07-30	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
779	883	1997-08-01	meeting	Site visit with purchasing.	Claire Martin
780	1281	1997-08-02	meeting	Site visit with purchasing.	Sam Carter
781	245	1997-08-03	complaint	Invoice dispute, resolved.	Luca Rossi
782	333	1997-08-04	complaint	Late delivery on two order lines.	Luca Rossi
783	229	1997-08-04	complaint	Invoice dispute, resolved.	Priya Shah
784	1158	1997-08-05	renewal	Annual supply agreement renewed on unchanged terms.	Claire Martin
785	708	1997-08-07	meeting	Site visit with purchasing.	Luca Rossi
786	797	1997-08-07	meeting	Site visit with purchasing.	Sam Carter
787	1046	1997-08-08	complaint	Invoice dispute, resolved.	Tom Becker
788	510	1997-08-08	renewal	Annual supply agreement renewed on unchanged terms.	Mei Lin
789	1428	1997-08-09	meeting	Site visit with purchasing.	Sam Carter
790	287	1997-08-10	meeting	Quarterly business review.	Sam Carter
791	1084	1997-08-10	meeting	Quarterly business review.	Sam Carter
792	1452	1997-08-12	support	Requested updated price list.	Anna Weber
793	346	1997-08-14	support	Requested updated price list.	Mei Lin
794	881	1997-08-15	meeting	Site visit with purchasing.	Luca Rossi
795	654	1997-08-16	meeting	Site visit with purchasing.	Tom Becker
796	1279	1997-08-19	meeting	Quarterly business review.	Mei Lin
797	529	1997-08-20	meeting	Site visit with purchasing.	Claire Martin
798	252	1997-08-21	renewal	Annual supply agreement renewed on unchanged terms.	Sam Carter
799	721	1997-08-22	complaint	Invoice dispute, resolved.	Mei Lin
800	991	1997-08-22	meeting	Quarterly business review.	Claire Martin
801	230	1997-08-23	meeting	Site visit with purchasing.	Mei Lin
802	1142	1997-08-23	meeting	Site visit with purchasing.	Priya Shah
803	310	1997-08-23	complaint	Late delivery on two order lines.	Luca Rossi
804	252	1997-08-24	support	Requested updated price list.	Sam Carter
805	359	1997-08-26	complaint	Invoice dispute, resolved.	Sam Carter
806	1088	1997-08-27	meeting	Quarterly business review.	Diego Santos
807	1419	1997-08-27	complaint	Invoice dispute, resolved.	Priya Shah
808	469	1997-08-28	meeting	Site visit with purchasing.	Priya Shah
809	169	1997-08-28	complaint	Late delivery on two order lines.	Mei Lin
810	680	1997-08-30	meeting	Site visit with purchasing.	Mei Lin
811	227	1997-08-31	meeting	Quarterly business review.	Sam Carter
812	1248	1997-09-01	complaint	Late delivery on two order lines.	Mei Lin
813	762	1997-09-01	meeting	Site visit with purchasing.	Priya Shah
814	342	1997-09-02	complaint	Invoice dispute, resolved.	Tom Becker
815	437	1997-09-04	complaint	Invoice dispute, resolved.	Diego Santos
816	1264	1997-09-04	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
817	503	1997-09-05	complaint	Invoice dispute, resolved.	Priya Shah
818	284	1997-09-06	complaint	Invoice dispute, resolved.	Luca Rossi
819	1088	1997-09-07	complaint	Invoice dispute, resolved.	Diego Santos
820	556	1997-09-08	complaint	Late delivery on two order lines.	Sam Carter
821	629	1997-09-09	meeting	Quarterly business review.	Sam Carter
822	496	1997-09-10	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
823	504	1997-09-13	complaint	Late delivery on two order lines.	Claire Martin
824	808	1997-09-13	complaint	Invoice dispute, resolved.	Diego Santos
825	721	1997-09-15	complaint	Late delivery on two order lines.	Mei Lin
826	1233	1997-09-16	meeting	Site visit with purchasing.	Anna Weber
827	1227	1997-09-16	complaint	Invoice dispute, resolved.	Claire Martin
828	1308	1997-09-17	complaint	Late delivery on two order lines.	Tom Becker
829	1039	1997-09-17	meeting	Site visit with purchasing.	Tom Becker
830	321	1997-09-19	meeting	Site visit with purchasing.	Priya Shah
831	1154	1997-09-20	meeting	Quarterly business review.	Diego Santos
832	161	1997-09-20	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
833	807	1997-09-21	complaint	Late delivery on two order lines.	Claire Martin
834	1471	1997-09-21	complaint	Invoice dispute, resolved.	Mei Lin
835	809	1997-09-22	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
836	1252	1997-09-22	support	Requested updated price list.	Priya Shah
837	715	1997-09-23	complaint	Invoice dispute, resolved.	Tom Becker
838	464	1997-09-24	support	Requested updated price list.	Luca Rossi
839	936	1997-09-25	complaint	Late delivery on two order lines.	Sam Carter
840	1225	1997-09-25	complaint	Late delivery on two order lines.	Luca Rossi
841	103	1997-09-26	meeting	Site visit with purchasing.	Luca Rossi
842	678	1997-09-26	complaint	Late delivery on two order lines.	Priya Shah
843	253	1997-09-26	complaint	Late delivery on two order lines.	Tom Becker
844	1445	1997-09-30	meeting	Site visit with purchasing.	Tom Becker
845	546	1997-10-02	support	Requested updated price list.	Sam Carter
846	228	1997-10-03	meeting	Quarterly business review.	Priya Shah
847	1075	1997-10-04	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
848	364	1997-10-05	meeting	Quarterly business review.	Diego Santos
849	591	1997-10-06	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
850	469	1997-10-07	complaint	Late delivery on two order lines.	Priya Shah
851	584	1997-10-10	renewal	Annual supply agreement renewed on unchanged terms.	Tom Becker
852	737	1997-10-10	complaint	Late delivery on two order lines.	Luca Rossi
853	1440	1997-10-12	complaint	Invoice dispute, resolved.	Mei Lin
854	1270	1997-10-13	meeting	Quarterly business review.	Anna Weber
855	1179	1997-10-13	complaint	Invoice dispute, resolved.	Mei Lin
856	273	1997-10-15	support	Requested updated price list.	Luca Rossi
857	572	1997-10-15	meeting	Site visit with purchasing.	Sam Carter
858	360	1997-10-17	complaint	Late delivery on two order lines.	Claire Martin
859	29	1997-10-19	complaint	Late delivery on two order lines.	Anna Weber
860	1121	1997-10-19	meeting	Quarterly business review.	Diego Santos
861	1373	1997-10-20	complaint	Late delivery on two order lines.	Priya Shah
862	979	1997-10-20	meeting	Quarterly business review.	Luca Rossi
863	925	1997-10-20	meeting	Site visit with purchasing.	Claire Martin
864	1309	1997-10-21	meeting	Quarterly business review.	Mei Lin
865	545	1997-10-23	support	Requested updated price list.	Mei Lin
866	1452	1997-10-23	support	Requested updated price list.	Anna Weber
867	787	1997-10-23	meeting	Quarterly business review.	Sam Carter
868	14	1997-10-24	meeting	Site visit with purchasing.	Tom Becker
869	1137	1997-10-24	meeting	Quarterly business review.	Luca Rossi
870	1395	1997-10-24	support	Requested updated price list.	Tom Becker
871	1258	1997-10-28	support	Requested updated price list.	Claire Martin
872	931	1997-10-29	meeting	Quarterly business review.	Mei Lin
873	1389	1997-10-30	meeting	Site visit with purchasing.	Luca Rossi
874	578	1997-10-30	meeting	Site visit with purchasing.	Luca Rossi
875	646	1997-11-01	meeting	Quarterly business review.	Tom Becker
876	1352	1997-11-01	meeting	Site visit with purchasing.	Anna Weber
877	759	1997-11-02	meeting	Site visit with purchasing.	Sam Carter
878	1415	1997-11-03	complaint	Late delivery on two order lines.	Diego Santos
879	711	1997-11-03	complaint	Invoice dispute, resolved.	Tom Becker
880	370	1997-11-05	support	Requested updated price list.	Sam Carter
881	1318	1997-11-05	meeting	Quarterly business review.	Diego Santos
882	960	1997-11-07	complaint	Invoice dispute, resolved.	Diego Santos
883	47	1997-11-07	complaint	Late delivery on two order lines.	Diego Santos
884	576	1997-11-08	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
885	1362	1997-11-10	meeting	Site visit with purchasing.	Luca Rossi
886	379	1997-11-11	complaint	Invoice dispute, resolved.	Tom Becker
887	1031	1997-11-11	support	Requested updated price list.	Sam Carter
888	91	1997-11-16	renewal	Annual supply agreement renewed on unchanged terms.	Diego Santos
889	460	1997-11-18	complaint	Late delivery on two order lines.	Tom Becker
890	1276	1997-11-19	meeting	Site visit with purchasing.	Sam Carter
891	579	1997-11-19	complaint	Invoice dispute, resolved.	Diego Santos
892	472	1997-11-20	meeting	Site visit with purchasing.	Mei Lin
893	753	1997-11-20	meeting	Quarterly business review.	Luca Rossi
894	1455	1997-11-20	support	Requested updated price list.	Luca Rossi
895	487	1997-11-21	renewal	Annual supply agreement renewed on unchanged terms.	Priya Shah
896	1051	1997-11-22	meeting	Site visit with purchasing.	Anna Weber
897	96	1997-11-27	complaint	Late delivery on two order lines.	Diego Santos
898	1381	1997-11-27	meeting	Site visit with purchasing.	Claire Martin
899	1091	1997-11-28	meeting	Quarterly business review.	Tom Becker
900	1263	1997-11-28	meeting	Site visit with purchasing.	Tom Becker
901	1087	1997-11-30	support	Requested updated price list.	Claire Martin
902	1064	1997-12-02	meeting	Site visit with purchasing.	Luca Rossi
903	1478	1997-12-03	meeting	Site visit with purchasing.	Diego Santos
904	1418	1997-12-05	meeting	Site visit with purchasing.	Luca Rossi
905	1240	1997-12-06	complaint	Late delivery on two order lines.	Claire Martin
906	1187	1997-12-07	meeting	Quarterly business review.	Diego Santos
907	203	1997-12-07	complaint	Late delivery on two order lines.	Tom Becker
908	399	1997-12-08	meeting	Quarterly business review.	Tom Becker
909	132	1997-12-08	meeting	Quarterly business review.	Claire Martin
910	997	1997-12-13	meeting	Quarterly business review.	Luca Rossi
911	687	1997-12-13	meeting	Site visit with purchasing.	Claire Martin
912	1502	1997-12-14	meeting	Quarterly business review.	Anna Weber
913	15	1997-12-16	meeting	Quarterly business review.	Priya Shah
914	116	1997-12-17	meeting	Site visit with purchasing.	Sam Carter
915	40	1997-12-24	meeting	Site visit with purchasing.	Priya Shah
916	1062	1997-12-25	complaint	Invoice dispute, resolved.	Tom Becker
917	165	1997-12-26	renewal	Annual supply agreement renewed on unchanged terms.	Anna Weber
918	68	1997-12-27	meeting	Site visit with purchasing.	Tom Becker
919	1055	1997-12-27	meeting	Site visit with purchasing.	Sam Carter
920	1181	1997-12-28	support	Requested updated price list.	Diego Santos
921	426	1997-12-29	renewal	Annual supply agreement renewed on unchanged terms.	Luca Rossi
\.
